package com.sistemaderiegoandroid_arduino;

public class DatosArduinoRString {
    protected  String activado;
    protected String andOr;
    protected  String fechainicio;
    protected String fechafin;
    protected String tiemporiego1;
    protected String diasSemana;
    protected String horainicio1;
    protected String horainicio2;
    protected String tiemporiego2;
    protected String humedad;
    protected String sensibilidadLuz;
    protected String nocheDia;
    protected String nroSolenoide;

    public DatosArduinoRString(String activado, String andOr, String fechainicio,String fechafin,String tiemporiego1,String diasSemana,String horainicio1,String horainicio2,String tiemporiego2,String humedad, String sensibilidadLuz, String nocheDia, String nroSolenoide){

        this.activado = activado;
        this.andOr= andOr;
        this.fechainicio=fechainicio;
        this.fechafin=fechafin;
        this.tiemporiego1=tiemporiego1;
        this.diasSemana=diasSemana;
        this.horainicio1=horainicio1;
        this.horainicio2=horainicio2;
        this.tiemporiego2=tiemporiego2;
        this.humedad=humedad;
        this.sensibilidadLuz=sensibilidadLuz;
        this.nocheDia=nocheDia;
        this.nroSolenoide = nroSolenoide;
    }

    public String getFechaInicio(){
        return this.fechainicio;};

    public String getFechaFin(){
        return this.fechafin;};

    public String getTiempoRiego1(){ return  this.tiemporiego1;}

    public String getDiasSemana(){
        return this.diasSemana;
    };
    public String getHoraInicio1(){
        return this.horainicio1;};

    public String getHorainicio2(){
        return this.horainicio2;};

    public String getTiempoRiego2(){

        return this.tiemporiego2;};

    public String getHumedad(){
        return this.humedad;};

    public String getSensibilidadLuz(){ return this.sensibilidadLuz;};

    public String getNocheDia(){

        return this.nocheDia;};

    public String getNroSolenoide(){
        return this.nroSolenoide;};


}


