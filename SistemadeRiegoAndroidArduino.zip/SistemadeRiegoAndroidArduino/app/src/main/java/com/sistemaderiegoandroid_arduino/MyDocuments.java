package com.sistemaderiegoandroid_arduino;

import android.content.Context;

import android.content.SharedPreferences;

import android.content.res.AssetFileDescriptor;

import android.content.res.TypedArray;

import android.database.Cursor;

import android.database.MatrixCursor;

import android.graphics.Point;

import android.os.Build;
import android.os.CancellationSignal;

import android.os.Handler;

import android.os.ParcelFileDescriptor;

import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;

import android.provider.DocumentsContract.Root;

import android.provider.DocumentsProvider;

import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.sistemaderiegoandroid_arduino.R;
import com.sistemaderiegoandroid_arduino.ui.Resumen.ResumenFragment;


import java.io.ByteArrayOutputStream;

import java.io.File;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.util.Collections;

import java.util.Comparator;

import java.util.HashSet;

import java.util.LinkedList;

import java.util.PriorityQueue;

import java.util.Set;

import static android.provider.DocumentsContract.*;

@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class MyDocuments extends DocumentsProvider {

    private static final String TAG = "MyDocuments";
    private static String[] DEFAULT_ROOT_PROJECTION =
            new String[]{Root.COLUMN_ROOT_ID, Root.COLUMN_MIME_TYPES,
                    Root.COLUMN_FLAGS, Root.COLUMN_TITLE,
                    Root.COLUMN_SUMMARY, Root.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Root.COLUMN_AVAILABLE_BYTES,};
    private static  String[] DEFAULT_DOCUMENT_PROJECTION = new
            String[]{Document.COLUMN_DOCUMENT_ID, Document.COLUMN_MIME_TYPE,
            Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_FLAGS, DocumentsContract.Document.COLUMN_SIZE,};

    private File mBaseDir = ResumenFragment.file;

    private static final String ROOT = "root";
    public static final String MINETYPE= "application/bin";
    public static final String AUTORITY = "com.sistemaderiegoandroid_arduino.documents";
    public static final int MAX_LAST_MODIFIED =12;
    public static String falloBorrar;
    public static String falloGrabar;
    public static String falloConsulta;
    public static String falloCrear;

    public static String fileSeparator = System.getProperty("file.separator");

    private static String[] resolveRootProjection(String[] projection) {

        return projection != null ? projection : DEFAULT_ROOT_PROJECTION;


    }




    @Override
    public Cursor queryRoots(String[] projection) throws FileNotFoundException {

        // Use a MatrixCursor to build a cursor
        // with either the requested fields, or the default
        // projection if "projection" is null.

        final MatrixCursor result =
                new MatrixCursor(resolveRootProjection(projection));
        final MatrixCursor.RowBuilder row = result.newRow();



        // FLAG_SUPPORTS_CREATE means at least one directory under the root supports
        // creating documents. FLAG_SUPPORTS_RECENTS means your application's most
        // recently used documents will show up in the "Recents" category.
        // FLAG_SUPPORTS_SEARCH allows users to search all documents the application
        // shares.
        row.add(Root.COLUMN_FLAGS,
                Root.FLAG_SUPPORTS_CREATE |
                Root.FLAG_SUPPORTS_RECENTS |
                Document.FLAG_DIR_SUPPORTS_CREATE |
                Root.FLAG_SUPPORTS_SEARCH|
                Document.FLAG_SUPPORTS_DELETE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            row.add(Root.COLUMN_FLAGS,
                    Document.FLAG_SUPPORTS_COPY|
                            Document.FLAG_SUPPORTS_REMOVE|
                            Document.FLAG_SUPPORTS_RENAME);
        }

        // COLUMN_TITLE is the root title (e.g. Gallery, Drive).
        row.add(Root.COLUMN_TITLE, getContext().getString(R.string.app_name));

        // This document id cannot change after it's shared.
        row.add(Root.COLUMN_DOCUMENT_ID, getDocIdForFile(mBaseDir));

        // The child MIME types are used to filter the roots and only present to the
        // user those roots that contain the desired type somewhere in their file hierarchy.
        row.add(Root.COLUMN_MIME_TYPES, MINETYPE);
        row.add(Root.COLUMN_AVAILABLE_BYTES, mBaseDir.getFreeSpace());
        row.add(Root.COLUMN_ICON, R.drawable.logo_sistema_riego_launch);
         return result;
    }

    private String getDocIdForFile(File file) {
        String path = file.getAbsolutePath();
        final String rootPath = mBaseDir.getPath();
        if (rootPath.equals(path)) {
            path = "";
        } else {
            path = path.substring(rootPath.length());
        }
        return "root" + ':' + path;
    }

    @Override
    public Cursor queryDocument(String documentId, String[] projection) throws FileNotFoundException {

        MatrixCursor result=null;

        final File parent = getFileForDocId(documentId);

        if (parent.isDirectory() & parent.listFiles()!=null) {

            result = new MatrixCursor(resolveDocumentProjection(projection));
            for (File file : parent.listFiles()) {
                includeFile(result, documentId, file);
            }
        }else{
            throw new FileNotFoundException(falloBorrar+ " :" + documentId);
        }

        return result;
    }


    private static String[] resolveDocumentProjection(String[] projection) {

        return projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION;
    }


    private void includeFile(MatrixCursor result, String docId, File file)
            throws FileNotFoundException {
        if (docId == null) {
            docId = getDocIdForFile(file);
        } else {
            file = getFileForDocId(docId);
        }
        int flags = 0;
        if (file.isDirectory()) {
// Request the folder to lay out as a grid rather than a list. This also allows a larger
// thumbnail to be displayed for each image.
// flags |= Document.FLAG_DIR_PREFERS_GRID;
// Add FLAG_DIR_SUPPORTS_CREATE if the file is a writable directory.
            if (file.canWrite()) {
                flags |= Document.FLAG_DIR_SUPPORTS_CREATE;
            } else if (file.canWrite()) {
// If the file is writable set FLAG_SUPPORTS_WRITE and
// FLAG_SUPPORTS_DELETE
                flags |= Document.FLAG_SUPPORTS_WRITE;
                flags |= Document.FLAG_SUPPORTS_DELETE;

            }
            final String displayName = file.getName();

            final MatrixCursor.RowBuilder row = result.newRow();
            row.add(Document.COLUMN_DOCUMENT_ID, docId);
            row.add(Document.COLUMN_DISPLAY_NAME, displayName);
            row.add(Document.COLUMN_SIZE, file.length());
            row.add(Document.COLUMN_MIME_TYPE, MINETYPE);
            row.add(Document.COLUMN_LAST_MODIFIED, file.lastModified());
            row.add(Document.COLUMN_FLAGS, flags);
// Add a custom icon
            row.add(Document.COLUMN_ICON, R.drawable.logo_sistema_riego_launch);
        }

    }

    @Override
    public Cursor queryRecentDocuments(String rootId, String[] projection)
            throws FileNotFoundException {

        // This example implementation walks a
        // local file structure to find the most recently
        // modified files.  Other implementations might
        // include making a network call to query a
        // server.

        // Create a cursor with the requested projection, or the default projection.
        final MatrixCursor result =
                new MatrixCursor(resolveDocumentProjection(projection));

        final File parent = getFileForDocId(rootId);

        // Create a queue to store the most recent documents,
        // which orders by last modified.
        PriorityQueue lastModifiedFiles = new PriorityQueue(5, new Comparator() {


                    @Override
                    public int compare(Object o1, Object o2) {
                        File i = (File) o1;
                        File j = (File) o2;
                        return compare(i.lastModified(), j.lastModified());
                    }

                });

        // Iterate through all files and directories
        // in the file structure under the root.  If
        // the file is more recent than the least
        // recently modified, add it to the queue,
        // limiting the number of results.
        final LinkedList pending = new LinkedList();

        // Start by adding the parent to the list of files to be processed
        pending.add(parent);

        // Do while we still have unexamined files
        while ((pending.size() >0)) {
            // Take a file from the list of unprocessed files
            final File file = (File) pending.removeFirst();
            if (file.isDirectory()) {
                // If it's a directory, add all its children to the unprocessed list
                Collections.addAll(pending, file.listFiles());
            } else {
                // If it's a file, add it to the ordered queue.
                lastModifiedFiles.add(file);
            }
        }

        // Add the most recent files to the cursor,
        // not exceeding the max number of results.
        for (int i = 0; i < Math.min(MAX_LAST_MODIFIED + 1, lastModifiedFiles.size()); i++) {
            final File file = (File) lastModifiedFiles.remove();
            includeFile(result, null, file);
        }
        return result;
    }


    @Override

    public void deleteDocument(String documentId) throws FileNotFoundException {


        File file = getFileForDocId(documentId);


        if (file.canWrite()) {

            file.delete();

        } else {

            throw new FileNotFoundException(falloBorrar+ " :" + documentId);

        }

    }
   private File getFileForDocId(String docId) throws FileNotFoundException {

            if (docId.equals(ROOT)){
            return mBaseDir;
                }
                final int splitIndex = docId.indexOf(':', 1);
                if (splitIndex < 0) {
                    throw new FileNotFoundException("Missing root for " + docId);
                } else {
                    final String path = docId.substring(splitIndex + 1);

                    File target = new File(mBaseDir, path);
                    if (!target.exists()) {
                        throw new FileNotFoundException(falloConsulta+ " :" + docId);
                    }
                    return target;
                }
            }




    @Override
    public Cursor queryChildDocuments(String parentDocumentId, String[] projection, String sortOrder) throws FileNotFoundException {

        MatrixCursor result= null;
        final File parent = getFileForDocId(parentDocumentId);

        if (parent.isDirectory() & parent.listFiles()!=null) {

            result = new MatrixCursor(resolveDocumentProjection(projection));
            for (File file : parent.listFiles()) {
                includeFile(result, null, file);
            }
        }else{
            throw new FileNotFoundException(falloConsulta+ " :" + parentDocumentId);
        }

        return result;

    }

        @Override

        public ParcelFileDescriptor openDocument(final String documentId, final String mode,

        CancellationSignal signal) throws FileNotFoundException {
        return null;

    }

    @Override
    public String getDocumentType(String documentId) throws FileNotFoundException {
        File file = getFileForDocId(documentId);
        return MINETYPE;}

    @Override
    public String createDocument(String documentId, String mimeType, String displayName)
            throws FileNotFoundException {
        Log.v(TAG, "createDocument");
        File parent = getFileForDocId(documentId);
        File file = new File(parent.getPath(), displayName);

        try {
            if(file.isFile()) {

                file.setWritable(true);
                if (!(parent.mkdirs())) {
                    parent.mkdir();
                }


                file.createNewFile();
                file.setReadable(true);
            }
            } catch (IOException e) {
            throw new FileNotFoundException(falloCrear +
                    displayName +" and documentId " + documentId);
        }
        return getDocIdForFile(file);
    }


    @Override
    public boolean onCreate() {


    //    getContext().getContentResolver().notifyChange(ResumenFragment.fileUri,null);

        return true;
    }
}
