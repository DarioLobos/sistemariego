package com.sistemaderiegoandroid_arduino;


public class DatosArduinoR extends DatosArduino{
    private static final long  serialVersionUID=5L;
    protected int horainicio1;
    protected int horainicio2;
    protected int tiemporiego2;
    protected int humedad;
    protected int sensibilidadLuz;
    protected int nocheDia;
    protected int nroSolenoide;
    public DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia, int nroSolenoide
    ){
        super(activado,andOr,fechainicio,fechafin,tiemporiego1,diasSemana);
        this.horainicio1=horainicio1;
        this.horainicio2=horainicio2;
        this.tiemporiego2=tiemporiego2;
        this.humedad=humedad;
        this.sensibilidadLuz=sensibilidadLuz;
        this.nocheDia=nocheDia;
        this.nroSolenoide = nroSolenoide;
    };

    public void setHoraInicio1(int horainicio1){
        this.horainicio1=horainicio1;
    };
    public void setHoraInicio2(int horainicio2){
        this.horainicio2=horainicio2;
    };

    public void setTiempoRiego2(int tiemporiego2){
        this.tiemporiego2=tiemporiego2;
    };

    public void setHumedad(int humedad){
        this.humedad=humedad;
    };

    public void setSensibilidadLuz(int sensibilidadLuz){
        this.sensibilidadLuz=sensibilidadLuz;
    };

    public void setNocheDia(int nocheDia){
        this.nocheDia=nocheDia;
    };
    @Override
    public void setAndOr(int andOr){
        this.andOr = andOr;
    };

    public int getNroSolenoide(){
        return this.nroSolenoide;
    };

    @Override
    public int getFechaInicio(){
        return this.fechainicio;
    };
    @Override
    public int getFechaFin(){
        return this.fechafin;
    };

    @Override
    public int getActivado(){
        return this.activado;
    };

    @Override
    public int getTiempoRiego1(){
        return this.tiemporiego1;
    };

    @Override
    public int getTiempoRiego2(){
        return this.tiemporiego2;
    };

    @Override
    public int getDiasSemana(){
        return this.diasSemana;
    }
    @Override
    public int getAndOr(){
        return this.andOr;
    }

    public int getHoraInicio1(){
        return this.horainicio1;
    };
    public int getHoraInicio2(){
        return this.horainicio2;
    };

    public int getHumedad(){
        return this.humedad;
    };

    public int getNocheDia(){
        return this.nocheDia;
    };

    public int getSensibilidadLuz(){
        return this.sensibilidadLuz;
    };


    @Override
    public void setActivado(int activado){
        this.activado = activado;
    };
}


