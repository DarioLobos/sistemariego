package com.sistemaderiegoandroid_arduino.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.sistemaderiegoandroid_arduino.MainActivity;
import com.sistemaderiegoandroid_arduino.R;


public class HomeFragment extends Fragment {
    static Context context;

    public View onCreateView(@NonNull LayoutInflater inflater,
            ViewGroup container, Bundle savedInstanceState)
    {
        View root = inflater.inflate(R.layout.fragment_home, container, false);


    return root;
    };
}