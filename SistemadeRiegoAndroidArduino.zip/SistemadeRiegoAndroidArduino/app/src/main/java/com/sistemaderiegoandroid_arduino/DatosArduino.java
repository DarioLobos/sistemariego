package com.sistemaderiegoandroid_arduino;


import java.io.*;


public class DatosArduino implements Serializable{
    private static final long  serialVersionUID=9L;
    public int activado;
    public int andOr;
    public int fechainicio;
    public int fechafin;
    public int horainicio1;
    public int horainicio2;
    public int tiemporiego1;
    public int tiemporiego2;
    public int diasSemana;
    public int humedad;
    public int sensibilidadLuz;
    public int nocheDia;
    public DatosArduinoR [] fileR = new DatosArduinoR[6];
    public DatosArduinoT [] fileT = new DatosArduinoT[6];
    public DatosArduinoH [] fileH = new DatosArduinoH[6];
    public DatosArduinoL [] fileL = new DatosArduinoL[6];

    public DatosArduino(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana){
        this.activado=activado;
        this.andOr=andOr;
        this.fechainicio=fechainicio;
        this.fechafin=fechafin;
        this.tiemporiego1=tiemporiego1;
        this.diasSemana=diasSemana;

    };

    public DatosArduino(DatosArduinoR [] fileR){
this.fileR = fileR;
    };
    public DatosArduino(DatosArduinoT [] fileT){
        this.fileT = fileT;
    };
    public DatosArduino(DatosArduinoH [] fileH){
        this.fileH = fileH;
    };
    public DatosArduino(DatosArduinoL [] fileL){
        this.fileL = fileL;
    };

    public int getFechaInicio(){
        return this.fechainicio;
    };
    public int getFechaFin(){
        return this.fechafin;
    };
    public int getActivado(){
        return this.activado;
    };
    public int getTiempoRiego1(){
        return this.tiemporiego1;
    };
    public int getTiempoRiego2(){
        return this.tiemporiego2;
    };
    public int getDiasSemana(){
        return this.diasSemana;
    }
    public int getAndOr(){
        return this.andOr;
    }

    public void setActivado(int activado){
        this.activado = activado;
    };
    public void setAndOr(int andOr){
        this.andOr = andOr;
    };


    public static void main(String[] args){


    }
}
