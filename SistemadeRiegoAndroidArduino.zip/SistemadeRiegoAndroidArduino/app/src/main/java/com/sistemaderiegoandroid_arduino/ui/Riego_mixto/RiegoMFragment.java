package com.sistemaderiegoandroid_arduino.ui.Riego_mixto;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.sistemaderiegoandroid_arduino.MainActivity;
import com.sistemaderiegoandroid_arduino.R;
import com.sistemaderiegoandroid_arduino.ui.home.HomeFragment;

import android.content.Context;

import static com.sistemaderiegoandroid_arduino.MainActivity.*;

public class RiegoMFragment extends Fragment {
    private Context context;

    private TableLayout riegomixto;
    RadioGroup.OnCheckedChangeListener a1;
    RadioGroup.OnCheckedChangeListener a2;
    RadioGroup.OnCheckedChangeListener a3;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.riegomixto, container, false);


        context = root.getContext();
        final Button actualizar = root.findViewById(R.id.actualizar);

        final TextView titulo =
                root.findViewById(R.id.titulo);
        final TextView riegoM =
                root.findViewById(R.id.riegoM);
        final TextView riegoLuz = root.findViewById(R.id.riegoM);
        final TextView riegoTiempo = root.findViewById(R.id.riegoTiempo);
        final TextView riegoHumedad = root.findViewById(R.id.riegoHumedad);
        final CheckBox rb1 =
                root.findViewById(R.id.rb1);
        final CheckBox rb2 =
                root.findViewById(R.id.rb2);
        final CheckBox rb3 =
                root.findViewById(R.id.rb3);
        final TextView debeMixto =
                root.findViewById(R.id.debeMixto);
        final TextView debeAndOr =
                root.findViewById(R.id.debeAndOr);
        final RadioGroup groupAndOr3 =
                root.findViewById(R.id.groupAndOr3);
        final RadioButton rbAnd3 =
                root.findViewById(R.id.rbAnd3);
        final RadioButton rbOr3 =
                root.findViewById(R.id.rbOr3);
        final RadioGroup groupAndOr2 =
                root.findViewById(R.id.groupAndOr2);
        final RadioButton rbAnd2 =
                root.findViewById(R.id.rbAnd2);
        final RadioButton rbOr2 =
                root.findViewById(R.id.rbOr2);
        final RadioGroup groupAndOr1 =
                root.findViewById(R.id.groupAndOr1);
        final RadioButton rbAnd1 =
                root.findViewById(R.id.rbAnd1);
        final RadioButton rbOr1 =
                root.findViewById(R.id.rbOr1);


        a1 = new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int d = allData.solenoidesRegistradosT();
                if (d > 0) {

                    switch (checkedId) {
                        case R.id.rbAnd1:
                            allData.setAndOrT(2);
                            Toast.makeText(context, "AND", Toast.LENGTH_SHORT).show();
                            break;
                        case R.id.rbOr1:
                            allData.setAndOrT(1);
                            Toast.makeText(context, "OR", Toast.LENGTH_SHORT).show();
                            break;
                        default:
                            allData.setAndOrT(-1);
                            break;
                    }
                    ;

                } else {


                    doClear(groupAndOr1, a1);


                }
                ;

            }
        };
        groupAndOr1.setOnCheckedChangeListener(a1);


        a2 = new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int d = allData.solenoidesRegistradosL();
                if (d > 0) {

                    switch (checkedId) {
                        case R.id.rbAnd2:
                            allData.setAndOrL(2);
                            Toast.makeText(context, "AND", Toast.LENGTH_SHORT).show();
                            break;
                        case R.id.rbOr2:
                            allData.setAndOrL(1);
                            Toast.makeText(context, "OR", Toast.LENGTH_SHORT).show();
                            break;
                        default:
                            allData.setAndOrL(-1);
                            break;
                    }
                    ;

                } else {
                    doClear(groupAndOr2, a2);
                }
                ;

            }
        };
        groupAndOr2.setOnCheckedChangeListener(a2);


        a3 = new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int d = allData.solenoidesRegistradosH();
                if (d > 0) {

                    switch (checkedId) {
                        case R.id.rbAnd3:
                            allData.setAndOrH(2);
                            Toast.makeText(context, "AND", Toast.LENGTH_SHORT).show();
                            break;
                        case R.id.rbOr3:
                            allData.setAndOrH(1);
                            Toast.makeText(context, "OR", Toast.LENGTH_SHORT).show();
                            break;
                        default:
                            allData.setAndOrH(-1);
                            break;
                    }
                    ;

                } else {


                    doClear(groupAndOr3, a3);


                }
                ;

            }

            ;
        };
        groupAndOr3.setOnCheckedChangeListener(a3);

        rb1.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    int d = allData.solenoidesRegistradosT();
                    if (d > 0) {

                        allData.activaSolenoideT(1);
                        Toast.makeText(context, getString(R.string.stToast9), Toast.LENGTH_SHORT).show();

                    } else {
                        rb1.setChecked(false);
                        Toast.makeText(context, getString(R.string.stToast8), Toast.LENGTH_SHORT).show();
                    }
                    ;
                } else {

                    allData.activaSolenoideT(-1);
                    Toast.makeText(context, getString(R.string.stToast10), Toast.LENGTH_SHORT).show();

                }

            }
        });

        rb2.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    int d = allData.solenoidesRegistradosL();
                    if (d > 0) {

                        allData.activaSolenoideL(1);
                        Toast.makeText(context, getString(R.string.stToast9), Toast.LENGTH_SHORT).show();

                    } else {
                        rb2.setChecked(false);
                        Toast.makeText(context, getString(R.string.stToast8), Toast.LENGTH_SHORT).show();
                    }
                    ;
                } else {

                    allData.activaSolenoideL(-1);
                    Toast.makeText(context, getString(R.string.stToast10), Toast.LENGTH_SHORT).show();

                }

            }
        });

        rb3.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    int d = allData.solenoidesRegistradosH();
                    if (d > 0) {

                        allData.activaSolenoideH(1);
                        Toast.makeText(context, getString(R.string.stToast9), Toast.LENGTH_SHORT).show();

                    } else {
                        rb3.setChecked(false);
                        Toast.makeText(context, getString(R.string.stToast8), Toast.LENGTH_SHORT).show();
                    }
                    ;
                } else {

                    allData.activaSolenoideH(-1);
                    Toast.makeText(context, getString(R.string.stToast10), Toast.LENGTH_SHORT).show();

                }

            }
        });
        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Toast.makeText(context, getString(R.string.stToast6), Toast.LENGTH_SHORT).show();


            }
        });

        return root;
    }

    ;


    public void doClear(final RadioGroup g,
                        RadioGroup.OnCheckedChangeListener a
    ) {

        Toast.makeText(context, getString(R.string.stToast8), Toast.LENGTH_SHORT).show();
        g.setOnCheckedChangeListener(null);
        g.clearCheck();
        g.setOnCheckedChangeListener(a);

    }

    ;
}


