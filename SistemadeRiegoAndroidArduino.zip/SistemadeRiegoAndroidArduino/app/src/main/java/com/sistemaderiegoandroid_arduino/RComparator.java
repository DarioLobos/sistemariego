package com.sistemaderiegoandroid_arduino;

import java.util.*;

public class RComparator implements Comparator<DatosArduinoR>{


    @Override
    public int compare(DatosArduinoR s1, DatosArduinoR s2){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia, int nroSolenoide

        if((s1!=null)&(s2!=null)){
            if (s1.equals(s2)) {
                return 0;
            }
            else if (s1.getNroSolenoide() > s2.getNroSolenoide()){
                return 1;
            }
            else if((s1.getNroSolenoide() == s2.getNroSolenoide())& (s1.getFechaInicio()<s2.getFechaInicio())){
                return 1;
            }
            else if((s1.getNroSolenoide() == s2.getNroSolenoide()) & (s1.getFechaInicio()==s2.getFechaInicio()) & (s1.getFechaFin() > s2.getFechaFin())){
                return 1;
            }
            else return -1;
        }else return -1;
    }
}
