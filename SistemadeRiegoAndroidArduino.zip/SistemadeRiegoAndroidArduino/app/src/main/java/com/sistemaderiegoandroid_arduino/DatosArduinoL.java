package com.sistemaderiegoandroid_arduino;

public class DatosArduinoL extends DatosArduino{
    public int sensibilidadLuz;
    public int nocheDia;


    public DatosArduinoL(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int sensibilidadLuz, int nocheDia){
        super(activado,andOr,fechainicio,fechafin,tiemporiego1,diasSemana);

        this.nocheDia=nocheDia;
        this.sensibilidadLuz=sensibilidadLuz;
    };

    public int getNocheDia(){
        return this.nocheDia;
    };

    public int getSensibilidadLuz(){
        return this.sensibilidadLuz;
    };


    @Override
    public int getFechaInicio(){
        return this.fechainicio;
    };
    @Override
    public int getFechaFin(){
        return this.fechafin;
    };

    @Override
    public int getActivado(){
        return this.activado;
    };

    @Override
    public int getTiempoRiego1(){
        return this.tiemporiego1;
    };


    @Override
    public int getDiasSemana(){
        return this.diasSemana;
    };

    @Override
    public int getAndOr(){
        return this.andOr;
    }
    @Override
    public void setActivado(int activado){
        this.activado = activado;
    };
    @Override
    public void setAndOr(int andOr){
        this.andOr = andOr;
    };


    public static void main(String[] args){






    }
}
