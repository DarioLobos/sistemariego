package com.sistemaderiegoandroid_arduino;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;

import com.sistemaderiegoandroid_arduino.ui.Resumen.ResumenFragment;
import java.io.*;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;
import java.util.ArrayList;

import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;


public class Data {

    public int request_code=0;
    public DatosArduinoT[] arrayDatosTiempo;
    public DatosArduinoH[] arrayDatosHumedad;
    public DatosArduinoL[] arrayDatosLuz;
    public DatosArduinoR[] arrayDatosResumen;
    File pathData;
    public static String error_save ="";
    public static String dirpath =Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+"/"+"sistemaderiegoandroid_arduino";

    public static String[] arrayDias =new String[]{"","","","","","","",""};

    public Data(){

        this.arrayDatosTiempo= new DatosArduinoT[6];

        this.arrayDatosHumedad= new DatosArduinoH[6];

        this.arrayDatosLuz = new DatosArduinoL[6];

        this.arrayDatosResumen = new
                DatosArduinoR[18];

    };

    public void programaSolenoideT(DatosArduinoT d,int nroSolenoide){
        this.arrayDatosTiempo[nroSolenoide]= d;
    };

    public void programaSolenoideL(DatosArduinoL d,int nroSolenoide){
        this.arrayDatosLuz[nroSolenoide]= d;
    };

    public void programaSolenoideH(DatosArduinoH d,int nroSolenoide){
        this.arrayDatosHumedad[nroSolenoide]= d;
    };

    public int solenoidesRegistradosT(){
        int compara=-1;
        for (int i=0; i < arrayDatosTiempo.length; i++){
            if (arrayDatosTiempo[i]!=null){

                compara= compara + arrayDatosTiempo[i].getFechaInicio();};
        };
        return compara;
    };

    public int solenoidesRegistradosH(){
        int compara=-1;
        for (int i=0; i < arrayDatosHumedad.length; i++){
            if (arrayDatosHumedad[i]!=null){
                compara= compara + arrayDatosHumedad[i].getFechaInicio();};
        };

        return compara;
    };
    public int getFechaInicioDataL(int nroSolenoide){
        int d=-1;
        if (arrayDatosLuz[nroSolenoide]!=null){ d=this.arrayDatosLuz[nroSolenoide].getFechaInicio();};
        return d;
    };

    public int solenoidesRegistradosL(){
        int compara=-1;
        for (int i=0; i < arrayDatosLuz.length; i++){
            if (arrayDatosLuz[i]!=null){
                compara= compara + arrayDatosLuz[i].getFechaInicio();};
        };
        return compara;
    };

    public int getFechaInicioDataT(int nroSolenoide){
        int d;
        if (arrayDatosTiempo[nroSolenoide]!=null){
            d= this.arrayDatosTiempo[nroSolenoide].getFechaInicio();
        }else{
            d=-1;};
        return d;
    };

    public void activaSolenoideT(int activa){

        for (int i=0; i < arrayDatosTiempo.length; i++){
            if (arrayDatosTiempo[i]!=null){
                if(this.arrayDatosTiempo[i].getFechaInicio()>0){
                    this.arrayDatosTiempo[i].setActivado(activa);}
            }};
    };

    public int getFechaInicioDataH(int nroSolenoide){
        int d=-1;
        if (arrayDatosHumedad[nroSolenoide]!=null){ d=this.arrayDatosHumedad[nroSolenoide].getFechaInicio();};
        return d;
    };

    public void activaSolenoideH(int activa){

        for (int i=0; i < arrayDatosHumedad.length; i++){
            if (arrayDatosHumedad[i]!=null){
                if(this.arrayDatosHumedad[i].getFechaInicio()>0){
                    this.arrayDatosHumedad[i].setActivado(activa);}
            }};
    };

    public void activaSolenoideL(int activa){

        for (int i=0; i < arrayDatosLuz.length; i++){
            if (arrayDatosLuz[i]!=null){
                if(this.arrayDatosLuz[i].getFechaInicio()>0){
                    this.arrayDatosLuz[i].setActivado(activa);}
            }};
    };

    public void setAndOrT(int activa){

        for (int i=0; i < arrayDatosTiempo.length; i++){
            if (arrayDatosTiempo[i]!=null){
                if(this.arrayDatosTiempo[i].getFechaInicio()>0){
                    this.arrayDatosTiempo[i].setAndOr(activa);}
            }};
    };

    public void setAndOrH(int activa){

        for (int i=0; i < arrayDatosHumedad.length; i++){
            if (arrayDatosHumedad[i]!=null){
                if(this.arrayDatosHumedad[i].getFechaInicio()>0){
                    this.arrayDatosHumedad[i].setAndOr(activa);}
            }};
    };

    public void setAndOrL(int activa){

        for (int i=0; i < arrayDatosLuz.length; i++){
            if (arrayDatosLuz[i]!=null){
                if(this.arrayDatosLuz[i].getFechaInicio()>0){
                    this.arrayDatosLuz[i].setAndOr(activa);}
            }};
    };
    DatosArduinoRString data;
    public ArrayList<DatosArduinoRString> FabricaResumen(){
        for (int i=0; i < arrayDatosResumen.length; i++){
            arrayDatosResumen[i]=null;};
        int contador=0;
        for (int i=0; i < arrayDatosTiempo.length; i++){
            if (arrayDatosTiempo[i]!=null){
                if((this.arrayDatosTiempo[i].getFechaInicio()>0) & (this.arrayDatosTiempo[i].getActivado()>0)){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia )
                    arrayDatosResumen[contador]=new DatosArduinoR(
                            arrayDatosTiempo[i].getActivado(),
                            arrayDatosTiempo[i].getAndOr(),
                            arrayDatosTiempo[i].getFechaInicio(),
                            arrayDatosTiempo[i].getFechaFin(),
                            arrayDatosTiempo[i].getTiempoRiego1(),
                            arrayDatosTiempo[i].getDiasSemana(),
                            arrayDatosTiempo[i].getHoraInicio1(),
                            arrayDatosTiempo[i].getHoraInicio2(),
                            arrayDatosTiempo[i].getTiempoRiego2(),
                            0,0,-1,(i+1));
                    contador=contador + 1;
                }}};
        for (int i=0; i < arrayDatosHumedad.length; i++){
            if (arrayDatosHumedad[i]!=null){
                if((this.arrayDatosHumedad[i].getFechaInicio()>0) & (this.arrayDatosHumedad[i].getActivado()>0)){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia)
                    arrayDatosResumen[contador]=new DatosArduinoR(
                            arrayDatosHumedad[i].getActivado(),
                            arrayDatosHumedad[i].getAndOr(),
                            arrayDatosHumedad[i].getFechaInicio(),
                            arrayDatosHumedad[i].getFechaFin(),
                            arrayDatosHumedad[i].getTiempoRiego1(),
                            arrayDatosHumedad[i].getDiasSemana(),
                            999999,
                            999999,
                            999999,
                            arrayDatosHumedad[i].getHumedad(),
                            0,-1,(i+1));
                    contador=contador+1;
                }}};
        for (int i=0; i < arrayDatosLuz.length; i++){
            if (arrayDatosLuz[i]!=null){
                if((this.arrayDatosLuz[i].getFechaInicio()>0) & (this.arrayDatosLuz[i].getActivado()>0)){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia)

                    arrayDatosResumen[contador]=new DatosArduinoR(
                            arrayDatosLuz[i].getActivado(),
                            arrayDatosLuz[i].getAndOr(),
                            arrayDatosLuz[i].getFechaInicio(),
                            arrayDatosLuz[i].getFechaFin(),
                            arrayDatosLuz[i].getTiempoRiego1(),
                            arrayDatosLuz[i].getDiasSemana(),
                            999999,
                            999999,
                            999999,
                            0,
                            arrayDatosLuz[i].getSensibilidadLuz(),
                            arrayDatosLuz[i].getNocheDia(),(i+1));
                    contador=contador+1;
                }}};
        ArrayList<DatosArduinoR> listaResumen =
                new ArrayList<DatosArduinoR>();
        listaResumen.clear();
        int c=0;
        for (int i=0; i < arrayDatosResumen.length; i++){
            if(arrayDatosResumen[i]!=null){
                c=c+1; listaResumen.add(arrayDatosResumen[i]);
            };};
        if(c==0){
            listaResumen.add(new DatosArduinoR(-1,0,0,0,0,0,0,0,0,0,0,-1,0));
        };
        Collections.sort(listaResumen,new RComparator());


        ArrayList<DatosArduinoRString> LResumenString =
                new ArrayList<DatosArduinoRString>();


        for (int i=0; i < listaResumen.size();i++){

//(String activado, String andOr, String fechainicio,String fechafin,String tiemporiego1,String diasSemana,String horainicio1,String horainicio2,String tiemporiego2,String humedad, String sensibilidadLuz, String nocheDia, String nroSolenoide){
            data = null;
            data = new DatosArduinoRString(
                    activado(listaResumen.get(i).getActivado()),
                    andor(listaResumen.get(i).getAndOr()),
                    makeintdate(listaResumen.get(i).getFechaInicio()),
                    makeintdate(listaResumen.get(i).getFechaFin()),
                    maketimertext(listaResumen.get(i).getTiempoRiego1()),
                    diasSeleccionados(listaResumen.get(i).getDiasSemana()),
                    makeinttime(listaResumen.get(i).getHoraInicio1()),
                    makeinttime(listaResumen.get(i).getHoraInicio2()),
                    maketimertext(listaResumen.get(i).getTiempoRiego2()),
                    Integer.toString(listaResumen.get(i).getHumedad()),
                    Integer.toString(listaResumen.get(i).getSensibilidadLuz()),
                    nochedia(listaResumen.get(i).getNocheDia()),
                    Integer.toString(listaResumen.get(i).getNroSolenoide()));

            LResumenString.add(data);
        };

        return LResumenString;
    };

    public String makeintdate(int a){
        int y = a/10000;
        int m = (a-(y*10000))/100;
        int d = (a-(y*10000+m*100));
        StringBuilder b = new StringBuilder().
                append(y).
                append("/").
                append(m).
                append("/").
                append(d);
        return b.toString();

    };

    public String makeinttime(int a){

        int h =a/100;
        int m = (a-(h*100));
        StringBuilder b = new StringBuilder().
                append("(H:M)24hrs").
                append(h).
                append(":").
                append(m);
        return b.toString();
    };
    public String maketimertext(int t){

        StringBuilder txt = new  StringBuilder().append(t).append(" Min.");
        return txt.toString();};

    public String diasSeleccionados(int diasSelected) {


        String txtDiasSelected;

        if ((diasSelected/128)==1){
            txtDiasSelected= arrayDias[0];
        }
        else{
            StringBuilder builDias =
                    new StringBuilder();
            for (int i = 0; i < 7; i++){
                int diasselector=diasSelected & (int)(Math.pow((double)2,(double)i));
                int bitOn = diasselector >> i;
                if (bitOn==1){ builDias.append(arrayDias[i+1]).append("  ");
                };
            };

            txtDiasSelected = builDias.toString();

        };
        return txtDiasSelected;
    };
    public String nochedia(int d){
        if(d==3){ return "D & N";}
        else if(d==2){
            return "D";}
        else if(d==1){
            return "N";}
        else return "-";
    }
    public String activado(int d){
        if(d==1){
            return "ON";
        }else return "OFF";
    }
    public String andor(int d){
        if(d==2){
            return "AND";
        }else if(d==1){
            return "OR"; }
        else return "-";
    }

    @RequiresApi(api = Build.VERSION_CODES.N)

    public void saveData(Context context, int option){
        int activado=0;
        for (int i = 0; i < MainActivity.allData.arrayDatosTiempo.length; i++) {
            activado =+ arrayDatosTiempo[i].getActivado();
        };
        for (int i = 0; i < MainActivity.allData.arrayDatosHumedad.length; i++) {
            activado =+ arrayDatosHumedad[i].getActivado();
        };
        for (int i = 0; i < MainActivity.allData.arrayDatosLuz.length; i++) {
            activado = + arrayDatosLuz[i].getActivado();
        };

        if (activado>0){
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"@filepaths/public_dir");
        Uri fileUri;
        File fileprivate = new File("@filepaths/private_dir");

        try {
            fileUri = FileProvider.getUriForFile(
                    context,
                    "com.sistemaderiegoandroid_arduino",
                    file);
        } catch (Exception e) {
            ResumenFragment.errorMsg(e.toString());
        };

        try{

            if (!file.mkdirs()) {
                file.mkdir();
            };}
        catch(Exception e){
            ResumenFragment.errorMsg(e.toString());
        }


        ObjectOutputStream serializatorDataR=null;
        ObjectOutputStream serializatorDataT=null;
        ObjectOutputStream serializatorDataL=null;
        ObjectOutputStream serializatorDataH=null;
        FileOutputStream arduinoDataR=null;
        FileOutputStream arduinoDataT=null;
        FileOutputStream arduinoDataH=null;
        FileOutputStream arduinoDataL=null;
        FileDescriptor fdR=null;
        FileDescriptor fdT=null;
        FileDescriptor fdH=null;
        FileDescriptor fdL=null;
        File fileNameR = null;
        File fileNameT = null;
        File fileNameH = null;
        File fileNameL = null;

        try {

            switch (option) {


                case 0:
                    fileNameR = new File(file, "arduino_data_resumen.bin");
                    fileNameT = new File(file, "arduino_data_tiempo.bin");
                    fileNameH = new File(file, "arduino_data_humedad.bin");
                    fileNameL = new File(file, "arduino_data_luz.bin");


                    break;
                case 1:

                    fileNameR = new File(fileprivate, "arduino_data_resumen.bin");
                    fileNameT = new File(fileprivate, "arduino_data_tiempo.bin");
                    fileNameH = new File(fileprivate, "arduino_data_humedad.bin");
                    fileNameL = new File(fileprivate, "arduino_data_luz.bin");


                    break;

                default:

                    fileNameR = new File(fileprivate, "arduino_data_resumen.bin");
                    fileNameT = new File(fileprivate, "arduino_data_tiempo.bin");
                    fileNameH = new File(fileprivate, "arduino_data_humedad.bin");
                    fileNameL = new File(fileprivate, "arduino_data_luz.bin");


                    break;
            };}catch(Exception e){
            ResumenFragment.errorMsg(e.toString());

        };
        if (fileNameR!=null & fileNameT!=null & fileNameH!=null & fileNameL!=null){
try {


    arduinoDataR = new FileOutputStream(fileNameR,false);
    fdR = arduinoDataR.getFD();
    serializatorDataR = new ObjectOutputStream(arduinoDataR);
    for (int i = 0; i < MainActivity.allData.arrayDatosResumen.length; i++) {

            serializatorDataR.writeObject(MainActivity.allData.arrayDatosResumen[i]);

            serializatorDataR.flush();
            fdR.sync();
    }
    ;
    serializatorDataR.close();


    arduinoDataT = new FileOutputStream(fileNameT, false);
    fdT = arduinoDataT.getFD();
    serializatorDataT = new ObjectOutputStream(arduinoDataT);
    for (int i = 0; i < MainActivity.allData.arrayDatosTiempo.length; i++) {

            serializatorDataT.writeObject(MainActivity.allData.arrayDatosTiempo[i]);

            serializatorDataT.flush();
            fdT.sync();


    };
    serializatorDataT.close();



    arduinoDataH = new FileOutputStream(fileNameH,false);
    fdH = arduinoDataH.getFD();
    serializatorDataH = new ObjectOutputStream(arduinoDataH);
    for (int i = 0; i < MainActivity.allData.arrayDatosHumedad.length; i++) {

            serializatorDataH.writeObject(MainActivity.allData.arrayDatosHumedad[i]);

            serializatorDataH.flush();
            fdH.sync();

    }
    ;

    serializatorDataH.close();


    arduinoDataL = new FileOutputStream(fileNameL,false);
    fdL = arduinoDataL.getFD();
    serializatorDataL = new ObjectOutputStream(arduinoDataL);
    for (int i = 0; i < MainActivity.allData.arrayDatosLuz.length; i++) {

            serializatorDataL.writeObject(MainActivity.allData.arrayDatosLuz[i]);

            serializatorDataL.flush();

            fdL.sync();

    }
    ;
    serializatorDataL.close();

    ResumenFragment.toastsave();

        }
        catch(Exception e){
            ResumenFragment.errorMsg(e.toString());
        }
        finally {

            if (serializatorDataR != null) {
                try {
                    serializatorDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (arduinoDataR != null) {
                try {
                    arduinoDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (serializatorDataT != null) {
                try {

                    serializatorDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());

                }
            };

            if (arduinoDataT != null) {
                try {
                    arduinoDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };
            if (serializatorDataH != null) {
                try {
                    serializatorDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (arduinoDataH != null) {
                try {
                    arduinoDataR.close();
                } catch (Exception e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };
            if (serializatorDataL != null) {
                try {
                    serializatorDataR.close();
                } catch (Exception e) {ResumenFragment.errorMsg(e.toString());
                }
            };

            if (arduinoDataL != null) {
                try {
                    arduinoDataR.close();
                } catch (Exception e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

        };}else{
              ResumenFragment.errorMsg(error_save);

        }
    };};
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void loadData(Context context, int option){
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"@filepaths/public_dir");
        Uri fileUri;
        File fileprivate = new File("@filepaths/private_dir");

        try {
            fileUri = FileProvider.getUriForFile(
                    context,
                    "com.sistemaderiegoandroid_arduino",
                    file);
        } catch (Exception e) {
            ResumenFragment.errorMsg(e.toString());

        };



        ObjectInputStream serializatorDataR=null;
        ObjectInputStream serializatorDataT=null;
        ObjectInputStream serializatorDataL=null;
        ObjectInputStream serializatorDataH=null;
        FileInputStream arduinoDataR=null;
        FileInputStream arduinoDataT=null;
        FileInputStream arduinoDataH=null;
        FileInputStream arduinoDataL=null;
        FileDescriptor fdR=null;
        FileDescriptor fdT=null;
        FileDescriptor fdH=null;
        FileDescriptor fdL=null;
        File fileNameR = null;
        File fileNameT = null;
        File fileNameH = null;
        File fileNameL = null;

        try {
            switch (option) {


                case 0:
                    fileNameR = new File(file, "arduino_data_resumen.bin");
                    fileNameT = new File(file, "arduino_data_tiempo.bin");
                    fileNameH = new File(file, "arduino_data_humedad.bin");
                    fileNameL = new File(file, "arduino_data_luz.bin");


                    break;
                case 1:

                    fileNameR = new File(fileprivate, "arduino_data_resumen.bin");
                    fileNameT = new File(fileprivate, "arduino_data_tiempo.bin");
                    fileNameH = new File(fileprivate, "arduino_data_humedad.bin");
                    fileNameL = new File(fileprivate, "arduino_data_luz.bin");


                    break;

                default:

                    fileNameR = new File(fileprivate, "arduino_data_resumen.bin");
                    fileNameT = new File(fileprivate, "arduino_data_tiempo.bin");
                    fileNameH = new File(fileprivate, "arduino_data_humedad.bin");
                    fileNameL = new File(fileprivate, "arduino_data_luz.bin");


                    break;
            };}catch(Exception e){
            ResumenFragment.errorMsg(e.toString());

        };

if (fileNameR!=null & fileNameT!=null & fileNameH!=null & fileNameL!=null){
        try {


            arduinoDataR = new FileInputStream(fileNameR);
            fdR = arduinoDataR.getFD();
            serializatorDataR = new ObjectInputStream(arduinoDataR);

            DatosArduinoR [] objectR = new DatosArduinoR[6];
                objectR = (DatosArduinoR[]) serializatorDataR.readObject();
                fdR.sync();
            for (int i = 0; i < 6; i++) {
                if (objectR != null) {

                    MainActivity.allData.arrayDatosResumen[i] = objectR[i];

                }else {MainActivity.allData.arrayDatosResumen[i] = null;}
                ;
            }
            ;
            serializatorDataR.close();
            objectR = null;

            arduinoDataT = new FileInputStream(fileNameT);
            fdT = arduinoDataT.getFD();
            serializatorDataT = new ObjectInputStream(arduinoDataT);
            DatosArduinoT [] objectT = new DatosArduinoT[6];
            objectT = (DatosArduinoT[]) serializatorDataT.readObject();
            fdT.sync();
            for (int i = 0; i < 6; i++) {
                if (objectT != null) {

                    MainActivity.allData.arrayDatosTiempo[i] = objectT[i];

                }else {MainActivity.allData.arrayDatosTiempo[i] = null;}
                ;
            }
            ;
            serializatorDataT.close();

            arduinoDataH = new FileInputStream(fileNameH);
            fdH = arduinoDataH.getFD();
            serializatorDataH = new ObjectInputStream(arduinoDataH);
            DatosArduinoH [] objectH = new DatosArduinoH[6];
            objectH = (DatosArduinoH[]) serializatorDataH.readObject();
            fdH.sync();
            for (int i = 0; i < 6; i++) {
                if (objectH != null) {

                    MainActivity.allData.arrayDatosHumedad[i] = objectH[i];

                }else {MainActivity.allData.arrayDatosHumedad[i] = null;}
                ;
            }
            ;
            serializatorDataH.close();
            objectH = null;

            arduinoDataL = new FileInputStream(fileNameL);
            fdL = arduinoDataL.getFD();
            serializatorDataL = new ObjectInputStream(arduinoDataL);
            DatosArduinoL [] objectL = new DatosArduinoL[6];
            objectL = (DatosArduinoL[]) serializatorDataL.readObject();
            fdL.sync();
            for (int i = 0; i < 6; i++) {
                if (objectL != null) {

                    MainActivity.allData.arrayDatosLuz[i] = objectL[i];

                }else {MainActivity.allData.arrayDatosLuz[i] = null;}
                ;
            }
            ;
            serializatorDataL.close();
            objectL = null;

            ResumenFragment.toastread();

        }
        catch(Exception e){
            ResumenFragment.errorMsg(e.toString());

            ResumenFragment.toastnotread();


        }
        finally {

            if (serializatorDataR != null) {
                try {
                    serializatorDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());

                }
            };

            if (arduinoDataR != null) {
                try {
                    arduinoDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (serializatorDataT != null) {
                try {
                    serializatorDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (arduinoDataT != null) {
                try {
                    arduinoDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };
            if (serializatorDataH != null) {
                try {
                    serializatorDataR.close();
                } catch (IOException e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (arduinoDataH != null) {
                try {
                    arduinoDataR.close();
                } catch (Exception e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };
            if (serializatorDataL != null) {
                try {
                    serializatorDataR.close();
                } catch (Exception e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

            if (arduinoDataL != null) {
                try {
                    arduinoDataR.close();
                } catch (Exception e) {
                    ResumenFragment.errorMsg(e.toString());
                }
            };

        };
    };};
}
