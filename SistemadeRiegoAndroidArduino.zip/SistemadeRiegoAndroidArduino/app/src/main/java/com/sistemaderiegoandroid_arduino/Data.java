package com.sistemaderiegoandroid_arduino;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import java.io.*;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;
import java.util.ArrayList;

import com.sistemaderiegoandroid_arduino.ui.Resumen.ResumenFragment;

import static android.content.Intent.ACTION_CREATE_DOCUMENT;
import static android.os.Environment.DIRECTORY_DOWNLOADS;
import static android.os.Environment.getExternalStoragePublicDirectory;
import static com.sistemaderiegoandroid_arduino.MainActivity.*;


public class Data extends Activity {

    public int request_code = 0;
    public static DatosArduinoT[] arrayDatosTiempo;
    private DatosArduinoT[] t = new DatosArduinoT[6];
    public static DatosArduinoH[] arrayDatosHumedad;
    private DatosArduinoH[] h = new DatosArduinoH[6];
    public static DatosArduinoL[] arrayDatosLuz;
    private DatosArduinoL[] l = new DatosArduinoL[6];
    public static DatosArduinoR[] arrayDatosResumen;
    public static Uri fileNameT;
    public static Uri fileNameH;
    public static Uri fileNameL;
    public static Uri fileNameR;
    File pathData;
    public static String dirpath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + "sistemaderiegoandroid_arduino";

    public static String[] arrayDias = new String[]{"", "", "", "", "", "", "", ""};

    public static String error_save = "";

    public Data() {

        for (int i = 0; i < 6; i ++){
    t[i]=new DatosArduinoT(-1,-1,-1,-1,-1,-1,-1,-1,-1);
};
        this.arrayDatosTiempo = t;

        for (int i = 0; i < 6; i ++){
            h[i]=new DatosArduinoH(-1,-1,-1,-1,-1,-1,-1);
        };

        this.arrayDatosHumedad = h;

        for (int i = 0; i < 6; i ++){
            l[i]=new DatosArduinoL(-1,-1,-1,-1,-1,-1,-1,-1);
        };

        this.arrayDatosLuz = l;

        this.arrayDatosResumen = new
                DatosArduinoR[18];
    };

    public void programaSolenoideT(DatosArduinoT d, int nroSolenoide) {
        this.arrayDatosTiempo[nroSolenoide] = d;
    };

    public void programaSolenoideL(DatosArduinoL d, int nroSolenoide) {
        this.arrayDatosLuz[nroSolenoide] = d;
    };

    public void programaSolenoideH(DatosArduinoH d, int nroSolenoide) {
        this.arrayDatosHumedad[nroSolenoide] = d;
    };

    public int solenoidesRegistradosT() {
        int compara = -1;
        for (DatosArduinoT datosArduinoT : arrayDatosTiempo) {
            if (datosArduinoT != null) {

                compara = compara + datosArduinoT.getFechaInicio();
            }
            ;
        }
        ;
        return compara;
    };

    public int solenoidesRegistradosH() {
        int compara = -1;
        for (DatosArduinoH datosArduinoH : arrayDatosHumedad) {
            if (datosArduinoH != null) {
                compara = compara + datosArduinoH.getFechaInicio();
            }
            ;
        }
        ;

        return compara;
    };

    public int getFechaInicioDataL(int nroSolenoide) {
        int d = -1;
        if (arrayDatosLuz[nroSolenoide] != null) {
            d = this.arrayDatosLuz[nroSolenoide].getFechaInicio();
        };
        return d;
    };

    public int solenoidesRegistradosL() {
        int compara = -1;
        for (DatosArduinoL datosArduinoL : arrayDatosLuz) {
            if (datosArduinoL != null) {
                compara = compara + datosArduinoL.getFechaInicio();
            }
            ;
        }
        ;
        return compara;
    };

    public int getFechaInicioDataT(int nroSolenoide) {
        int d;
        if (arrayDatosTiempo[nroSolenoide] != null) {
            d = this.arrayDatosTiempo[nroSolenoide].getFechaInicio();
        } else {
            d = -1;
        };
        return d;
    };

    public void activaSolenoideT(int activa) {

        for (DatosArduinoT datosArduinoT : arrayDatosTiempo) {
            if (datosArduinoT != null) {
                if (datosArduinoT.getFechaInicio() > 0) {
                    datosArduinoT.setActivado(activa);
                }
            }
        };
    };

    public int getFechaInicioDataH(int nroSolenoide) {
        int d = -1;
        if (arrayDatosHumedad[nroSolenoide] != null) {
            d = this.arrayDatosHumedad[nroSolenoide].getFechaInicio();
        };
        return d;
    };

    public void activaSolenoideH(int activa) {

        for (DatosArduinoH datosArduinoH : arrayDatosHumedad) {
            if (datosArduinoH != null) {
                if (datosArduinoH.getFechaInicio() > 0) {
                    datosArduinoH.setActivado(activa);
                }
            }
        };
    };

    public void activaSolenoideL(int activa) {

        for (DatosArduinoL datosArduinoL : arrayDatosLuz) {
            if (datosArduinoL != null) {
                if (datosArduinoL.getFechaInicio() > 0) {
                    datosArduinoL.setActivado(activa);
                }
            }
        };
    };

    public void setAndOrT(int activa) {

        for (DatosArduinoT datosArduinoT : arrayDatosTiempo) {
            if (datosArduinoT != null) {
                if (datosArduinoT.getFechaInicio() > 0) {
                    datosArduinoT.setAndOr(activa);
                }
            }
        };
    };

    public void setAndOrH(int activa) {

        for (DatosArduinoH datosArduinoH : arrayDatosHumedad) {
            if (datosArduinoH != null) {
                if (datosArduinoH.getFechaInicio() > 0) {
                    datosArduinoH.setAndOr(activa);
                }
            }
        };
    };

    public void setAndOrL(int activa) {

        for (DatosArduinoL datosArduinoL : arrayDatosLuz) {
            if (datosArduinoL != null) {
                if (datosArduinoL.getFechaInicio() > 0) {
                    datosArduinoL.setAndOr(activa);
                }
            }
        };
    };
    DatosArduinoRString data;

    public ArrayList<DatosArduinoRString> FabricaResumen() {
        for (int i = 0; i < arrayDatosResumen.length; i++) {
            arrayDatosResumen[i] = null;
        };
        int contador = 0;
        for (int i = 0; i < arrayDatosTiempo.length; i++) {
            if (arrayDatosTiempo[i] != null) {
                if ((this.arrayDatosTiempo[i].getFechaInicio() > 0) & (this.arrayDatosTiempo[i].getActivado() > 0)) {
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia )
                    arrayDatosResumen[contador] = new DatosArduinoR(
                            arrayDatosTiempo[i].getActivado(),
                            arrayDatosTiempo[i].getAndOr(),
                            arrayDatosTiempo[i].getFechaInicio(),
                            arrayDatosTiempo[i].getFechaFin(),
                            arrayDatosTiempo[i].getTiempoRiego1(),
                            arrayDatosTiempo[i].getDiasSemana(),
                            arrayDatosTiempo[i].getHoraInicio1(),
                            arrayDatosTiempo[i].getHoraInicio2(),
                            arrayDatosTiempo[i].getTiempoRiego2(),
                            0, 0, -1, (i + 1));
                    contador = contador + 1;
                }
            }
        };
        for (int i = 0; i < arrayDatosHumedad.length; i++) {
            if (arrayDatosHumedad[i] != null) {
                if ((this.arrayDatosHumedad[i].getFechaInicio() > 0) & (this.arrayDatosHumedad[i].getActivado() > 0)) {
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia)
                    arrayDatosResumen[contador] = new DatosArduinoR(
                            arrayDatosHumedad[i].getActivado(),
                            arrayDatosHumedad[i].getAndOr(),
                            arrayDatosHumedad[i].getFechaInicio(),
                            arrayDatosHumedad[i].getFechaFin(),
                            arrayDatosHumedad[i].getTiempoRiego1(),
                            arrayDatosHumedad[i].getDiasSemana(),
                            999999,
                            999999,
                            999999,
                            arrayDatosHumedad[i].getHumedad(),
                            0, -1, (i + 1));
                    contador = contador + 1;
                }
            }
        }
        ;
        for (int i = 0; i < arrayDatosLuz.length; i++) {
            if (arrayDatosLuz[i] != null) {
                if ((this.arrayDatosLuz[i].getFechaInicio() > 0) & (this.arrayDatosLuz[i].getActivado() > 0)) {
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia)

                    arrayDatosResumen[contador] = new DatosArduinoR(
                            arrayDatosLuz[i].getActivado(),
                            arrayDatosLuz[i].getAndOr(),
                            arrayDatosLuz[i].getFechaInicio(),
                            arrayDatosLuz[i].getFechaFin(),
                            arrayDatosLuz[i].getTiempoRiego1(),
                            arrayDatosLuz[i].getDiasSemana(),
                            999999,
                            999999,
                            999999,
                            0,
                            arrayDatosLuz[i].getSensibilidadLuz(),
                            arrayDatosLuz[i].getNocheDia(), (i + 1));
                    contador = contador + 1;
                }
            }
        };
        ArrayList<DatosArduinoR> listaResumen =
                new ArrayList<DatosArduinoR>();
        listaResumen.clear();
        int c = 0;
        for (DatosArduinoR arrayDatosResuman : arrayDatosResumen) {
            if (arrayDatosResuman != null) {
                c = c + 1;
                listaResumen.add(arrayDatosResuman);
            };
        };
        if (c == 0) {
            listaResumen.add(new DatosArduinoR(-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0));
        };
        Collections.sort(listaResumen, new RComparator());


        ArrayList<DatosArduinoRString> LResumenString =
                new ArrayList<DatosArduinoRString>();


        for (int i = 0; i < listaResumen.size(); i++) {

//(String activado, String andOr, String fechainicio,String fechafin,String tiemporiego1,String diasSemana,String horainicio1,String horainicio2,String tiemporiego2,String humedad, String sensibilidadLuz, String nocheDia, String nroSolenoide){
            data = null;
            data = new DatosArduinoRString(
                    activado(listaResumen.get(i).getActivado()),
                    andor(listaResumen.get(i).getAndOr()),
                    makeintdate(listaResumen.get(i).getFechaInicio()),
                    makeintdate(listaResumen.get(i).getFechaFin()),
                    maketimertext(listaResumen.get(i).getTiempoRiego1()),
                    diasSeleccionados(listaResumen.get(i).getDiasSemana()),
                    makeinttime(listaResumen.get(i).getHoraInicio1()),
                    makeinttime(listaResumen.get(i).getHoraInicio2()),
                    maketimertext(listaResumen.get(i).getTiempoRiego2()),
                    Integer.toString(listaResumen.get(i).getHumedad()),
                    Integer.toString(listaResumen.get(i).getSensibilidadLuz()),
                    nochedia(listaResumen.get(i).getNocheDia()),
                    Integer.toString(listaResumen.get(i).getNroSolenoide()));

            LResumenString.add(data);
        };

        return LResumenString;
    };

    public String makeintdate(int a) {
        int y = a / 10000;
        int m = (a - (y * 10000)) / 100;
        int d = (a - (y * 10000 + m * 100));
        StringBuilder b = new StringBuilder().
                append(y).
                append("/").
                append(m).
                append("/").
                append(d);
        return b.toString();

    };

    public String makeinttime(int a) {

        int h = a / 100;
        int m = (a - (h * 100));
        StringBuilder b = new StringBuilder().
                append("(H:M)24hrs").
                append(h).
                append(":").
                append(m);
        return b.toString();
    };

    public String maketimertext(int t) {

        StringBuilder txt = new StringBuilder().append(t).append(" Min.");
        return txt.toString();
    };

    public String diasSeleccionados(int diasSelected) {


        String txtDiasSelected;

        if ((diasSelected / 128) == 1) {
            txtDiasSelected = arrayDias[0];
        } else {
            StringBuilder builDias =
                    new StringBuilder();
            for (int i = 0; i < 7; i++) {
                int diasselector = diasSelected & (int) (Math.pow((double) 2, (double) i));
                int bitOn = diasselector >> i;
                if (bitOn == 1) {
                    builDias.append(arrayDias[i + 1]).append("  ");
                };
            };

            txtDiasSelected = builDias.toString();

        };
        return txtDiasSelected;
    };

    public String nochedia(int d) {
        if (d == 3) {
            return "D & N";
        } else if (d == 2) {
            return "D";
        } else if (d == 1) {
            return "N";
        } else return "-";
    }

    public String activado(int d) {
        if (d == 1) {
            return "ON";
        } else return "OFF";
    }

    public String andor(int d) {
        if (d == 2) {
            return "AND";
        } else if (d == 1) {
            return "OR";
        } else return "-";
    }

    public void saveData(Context context) {


            ObjectOutputStream serializatorDataR = null;
            ObjectOutputStream serializatorDataT = null;
            ObjectOutputStream serializatorDataL = null;
            ObjectOutputStream serializatorDataH = null;
            FileOutputStream arduinoDataR = null;
            FileOutputStream arduinoDataT = null;
            FileOutputStream arduinoDataH = null;
            FileOutputStream arduinoDataL = null;
            ParcelFileDescriptor parcelFileDescriptorR=null;
            ParcelFileDescriptor parcelFileDescriptorT=null;
            ParcelFileDescriptor parcelFileDescriptorH=null;
            ParcelFileDescriptor parcelFileDescriptorL=null;
            FileDescriptor fdR = null;
            FileDescriptor fdT = null;
            FileDescriptor fdH = null;
            FileDescriptor fdL = null;

        if (fileNameR != null & fileNameT != null & fileNameH != null & fileNameL != null) {


                try {
                    MyDocuments myDocuments= new MyDocuments();
                    parcelFileDescriptorR = getContentResolver().openFileDescriptor(fileNameR,"MODE_APPEND",null);
                    fdR = parcelFileDescriptorR.getFileDescriptor();
                    arduinoDataR = new FileOutputStream(fdR);

                    serializatorDataR = new ObjectOutputStream(arduinoDataR);
                    for (int i = 0; i < allData.arrayDatosResumen.length; i++) {

                        serializatorDataR.writeObject(allData.arrayDatosResumen[i]);

                        serializatorDataR.flush();
                        fdR.sync();
                    };
                    serializatorDataR.close();

                    if(ResumenFragment.activadoT>0){

                        parcelFileDescriptorT = getContentResolver().openFileDescriptor(fileNameT,"MODE_APPEND",null);
                        fdT = parcelFileDescriptorT.getFileDescriptor();
                        arduinoDataT = new FileOutputStream(fdT);

                        serializatorDataT = new ObjectOutputStream(arduinoDataT);
                        for (int i = 0; i < allData.arrayDatosTiempo.length; i++) {

                            serializatorDataT.writeObject(allData.arrayDatosTiempo[i]);

                            serializatorDataT.flush();
                            fdT.sync();


                        };
                        serializatorDataT.close();};

                    if(ResumenFragment.activadoH>0){
                        parcelFileDescriptorH = getContentResolver().openFileDescriptor(fileNameH,"MODE_APPEND",null);
                        fdR = parcelFileDescriptorH.getFileDescriptor();
                        arduinoDataH = new FileOutputStream(fdH);
                        serializatorDataH = new ObjectOutputStream(arduinoDataH);
                        for (int i = 0; i < allData.arrayDatosHumedad.length; i++) {

                            serializatorDataH.writeObject(allData.arrayDatosHumedad[i]);

                            serializatorDataH.flush();
                            fdH.sync();

                        };

                        serializatorDataH.close();};

                    if(ResumenFragment.activadoL>0){
                        parcelFileDescriptorL = getContentResolver().openFileDescriptor(fileNameL,"MODE_APPEND",null);
                        fdL = parcelFileDescriptorL.getFileDescriptor();
                        arduinoDataL = new FileOutputStream(fdL);
                        serializatorDataL = new ObjectOutputStream(arduinoDataL);
                        for (int i = 0; i < allData.arrayDatosLuz.length; i++) {

                            serializatorDataL.writeObject(allData.arrayDatosLuz[i]);

                            serializatorDataL.flush();

                            fdL.sync();

                        };
                        serializatorDataL.close();};

                    ResumenFragment.toastsave();

                } catch (Exception e) {
                    ResumenFragment.errorMsg("MAPPING ARRAYS" + e.toString());
                } finally {

                    if (serializatorDataR != null) {
                        try {
                            serializatorDataR.close();
                        } catch (IOException e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" + e.toString());
                        }
                    };

                    if (arduinoDataR != null) {
                        try {
                            arduinoDataR.close();
                        } catch (IOException e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };

                    if (serializatorDataT != null) {
                        try {

                            serializatorDataT.close();
                        } catch (IOException e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };

                    if (arduinoDataT != null) {
                        try {
                            arduinoDataT.close();
                        } catch (IOException e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };
                    if (serializatorDataH != null) {
                        try {
                            serializatorDataH.close();
                        } catch (IOException e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };

                    if (arduinoDataH != null) {
                        try {
                            arduinoDataH.close();
                        } catch (Exception e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };
                    if (serializatorDataL != null) {
                        try {
                            serializatorDataL.close();
                        } catch (Exception e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };

                    if (arduinoDataL != null) {
                        try {
                            arduinoDataL.close();
                        } catch (Exception e) {
                            ResumenFragment.errorMsg("FINALLY CLOSING FILES" +e.toString());
                        }
                    };
                };
            } else {
                ResumenFragment.errorMsg(error_save);

            }
}

    public static final int CREATE_FILE = 1;
    public static final int OPEN_FILE = 2;

    public void loadData(Context context) {

        ObjectInputStream serializatorDataR = null;
        ObjectInputStream serializatorDataT = null;
        ObjectInputStream serializatorDataL = null;
        ObjectInputStream serializatorDataH = null;
        FileInputStream arduinoDataR = null;
        FileInputStream arduinoDataT = null;
        FileInputStream arduinoDataH = null;
        FileInputStream arduinoDataL = null;
        ParcelFileDescriptor parcelFileDescriptorR=null;
        ParcelFileDescriptor parcelFileDescriptorT=null;
        ParcelFileDescriptor parcelFileDescriptorH=null;
        ParcelFileDescriptor parcelFileDescriptorL=null;
        FileDescriptor fdR = null;
        FileDescriptor fdT = null;
        FileDescriptor fdH = null;
        FileDescriptor fdL = null;

        if (fileNameR != null & fileNameT != null & fileNameH != null & fileNameL != null) {
            try {
                parcelFileDescriptorR = getContentResolver().openFileDescriptor(fileNameR,"MODE_READ_ONLY",null);
                fdR = parcelFileDescriptorR.getFileDescriptor();
                arduinoDataR = new FileInputStream(fdR);
                serializatorDataR = new ObjectInputStream(arduinoDataR);

                DatosArduinoR[] objectR = new DatosArduinoR[6];
                objectR = (DatosArduinoR[]) serializatorDataR.readObject();
                fdR.sync();
                for (int i = 0; i < 6; i++) {
                    if (objectR != null) {

                        allData.arrayDatosResumen[i] = objectR[i];

                    } else {
                        allData.arrayDatosResumen[i] = null;
                    };
                };
                serializatorDataR.close();
                objectR = null;

                parcelFileDescriptorT = getContentResolver().openFileDescriptor(fileNameT,"MODE_READ_ONLY",null);
                fdT = parcelFileDescriptorT.getFileDescriptor();
                arduinoDataT = new FileInputStream(fdT);
                serializatorDataT = new ObjectInputStream(arduinoDataT);
                DatosArduinoT[] objectT = new DatosArduinoT[6];
                objectT = (DatosArduinoT[]) serializatorDataT.readObject();
                fdT.sync();
                for (int i = 0; i < 6; i++) {
                    if (objectT != null) {

                        allData.arrayDatosTiempo[i] = objectT[i];

                    } else {
                        allData.arrayDatosTiempo[i] = null;
                    };
                };
                serializatorDataT.close();

                parcelFileDescriptorH = getContentResolver().openFileDescriptor(fileNameH,"MODE_READ_ONLY",null);
                fdH = parcelFileDescriptorH.getFileDescriptor();
                arduinoDataH = new FileInputStream(fdH);
                serializatorDataH = new ObjectInputStream(arduinoDataH);
                DatosArduinoH[] objectH = new DatosArduinoH[6];
                objectH = (DatosArduinoH[]) serializatorDataH.readObject();
                fdH.sync();
                for (int i = 0; i < 6; i++) {
                    if (objectH != null) {

                        allData.arrayDatosHumedad[i] = objectH[i];

                    } else {
                        allData.arrayDatosHumedad[i] = null;
                    };
                };
                serializatorDataH.close();

                parcelFileDescriptorL = getContentResolver().openFileDescriptor(fileNameL,"MODE_READ_ONLY",null);
                fdL = parcelFileDescriptorL.getFileDescriptor();
                serializatorDataL = new ObjectInputStream(arduinoDataL);
                DatosArduinoL[] objectL = new DatosArduinoL[6];
                objectL = (DatosArduinoL[]) serializatorDataL.readObject();
                fdL.sync();
                for (int i = 0; i < 6; i++) {
                    if (objectL != null) {

                        allData.arrayDatosLuz[i] = objectL[i];

                    } else {
                        allData.arrayDatosLuz[i] = null;
                    }
                    ;
                }
                ;
                serializatorDataL.close();
                objectL = null;

                ResumenFragment.toastread();

            } catch (Exception e) {
                ResumenFragment.errorMsg(e.toString());

                ResumenFragment.toastnotread();


            } finally {

                if (serializatorDataR != null) {
                    try {
                        serializatorDataR.close();
                    } catch (IOException e) {
                        ResumenFragment.errorMsg(e.toString());

                    }
                };

                if (arduinoDataR != null) {
                    try {
                        arduinoDataR.close();
                    } catch (IOException e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };

                if (serializatorDataT != null) {
                    try {
                        serializatorDataT.close();
                    } catch (IOException e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };

                if (arduinoDataT != null) {
                    try {
                        arduinoDataT.close();
                    } catch (IOException e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };
                if (serializatorDataH != null) {
                    try {
                        serializatorDataH.close();
                    } catch (IOException e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };

                if (arduinoDataH != null) {
                    try {
                        arduinoDataH.close();
                    } catch (Exception e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };
                if (serializatorDataL != null) {
                    try {
                        serializatorDataL.close();
                    } catch (Exception e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };

                if (arduinoDataL != null) {
                    try {
                        arduinoDataL.close();
                    } catch (Exception e) {
                        ResumenFragment.errorMsg(e.toString());
                    }
                };

            };
        };
    };


}