package com.sistemaderiegoandroid_arduino;

import android.net.Uri;
import android.provider.DocumentsContract;
import android.view.LayoutInflater;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;


import android.app.AlertDialog;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.AbsListView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.material.chip.Chip;
import com.sistemaderiegoandroid_arduino.ui.Resumen.ResumenFragment;
import com.sistemaderiegoandroid_arduino.ui.home.HomeFragment;

import java.lang.StringBuilder;
import java.util.Calendar;
import java.lang.Math;


public class SoleTiempo extends Fragment {

    private int nroSolenoide;
    private DatePicker datepicker;
    private static  int year, month ,day,hora,minuto;
    private static int fechaInicio;
    private static int horaRiego1;
    private static int fechaFin;
    private static int horaRiego2;
    private TextView txtfechaInicio;
    private TextView txtHoraRiego1;
    private TextView txtfechaFin;
    private TextView txtHoraRiego2;
    private Button boton;
    private static int datatoiniciofin= 0;
    private static int datatoiniciofint= 0;
    private static int tiempoRiego1;
    private static int tiempoRiego2;
    private TextView txtTiempo1;
    private TextView txtTiempo2;
    private static String [] arrayDias = new String[8];
    private Context context;

    private static int diasSelected=0;

    private static int setDias=0;

    private static boolean [] arrayCkDias = {false,false,false,false,false,false,false,false};
    private AlertDialog alertDialog;
    private TextView diasTexto;
    private static int unRiegoFlag=0;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.datos_tiempo, container, false);

      context = root.getContext();


       Bundle tiempo = new Bundle();
        nroSolenoide = (int) tiempo.getInt("nrosolenoide");
        final TextView titulo = (TextView) root.findViewById(R.id.titulo);
        final TextView riegoT = (TextView) root.findViewById(R.id.riegoT);
        final TextView soleNro = (TextView)
                root.findViewById(R.id.soleNro);
        final TextView textFechaInicio = (TextView)
                root.findViewById(R.id.fechaInicio);
        final TextView textfechaFin = (TextView) root.findViewById(R.id.fechaFin);
        final Button dPickInicio = root.findViewById(R.id.dPickInicio);
        final Button dPickFin = root.findViewById(R.id.dPickFin);
        final TextView textHoraRiego1 =
                (TextView) root.findViewById(R.id.horaRiego1);
        final TextView textHoraRiego2 = (TextView) root.findViewById(R.id.horaRiego2);
        final Button pkHoraRiego1 = root.findViewById(R.id.pkHoraRiego1);
        final Button pkHoraRiego2 = root.findViewById(R.id.pkHoraRiego2);
        txtfechaInicio = (TextView) root.findViewById(R.id.dateInicio);
        txtHoraRiego1 = (TextView) root.findViewById(R.id.timeRiego1);
        txtfechaFin = (TextView) root.findViewById(R.id.dateFin);
        txtHoraRiego2 = (TextView) root.findViewById(R.id.timeRiego2);
        final Button tiempo1 =
                root.findViewById(R.id.tiempo1);
        final Button tiempo2 =
                root.findViewById(R.id.tiempo2);
        txtTiempo1 = (TextView)
                root.findViewById(R.id.txtTiempo1);
        txtTiempo2 = (TextView)
                root.findViewById(R.id.txtTiempo2);
        diasTexto= (TextView) root.findViewById(R.id.diasTexto);
        Button actualizar= (Button) root.findViewById(R.id.actualizar);
        Button dias2 = root.findViewById(R.id.dias);
        final CheckBox unRiego = root.findViewById(R.id.unRiego);
        final CheckBox noDate = root.findViewById(R.id.noDate);
        arrayDias[0]=getString(R.string.todosDias);
        arrayDias[1]=getString(R.string.lunes);
        arrayDias[2]=getString(R.string.martes);
        arrayDias[3]=getString(R.string.miercoles);
        arrayDias[4]=getString(R.string.jueves);
        arrayDias[5]=getString(R.string.viernes);
        arrayDias[6]=getString(R.string.Sabado);
        arrayDias[7]=getString(R.string.Domingo);




        if (MainActivity.allData.getFechaInicioDataT(nroSolenoide)>0){
            makeintdate(txtfechaInicio, MainActivity.allData.getFechaInicioDataT(nroSolenoide));

            makeintdate(txtfechaFin, MainActivity.allData.arrayDatosTiempo[nroSolenoide].fechafin);

            makeinttime(txtHoraRiego1,MainActivity.allData.arrayDatosTiempo[nroSolenoide].horainicio1);

            makeinttime(txtHoraRiego2, MainActivity.allData.arrayDatosTiempo[nroSolenoide].horainicio2);

            maketimertext1(MainActivity.allData.arrayDatosTiempo[nroSolenoide].tiemporiego1);

            maketimertext2( MainActivity.allData.arrayDatosTiempo[nroSolenoide].tiemporiego2);

            String text_show = getString(R.string.txtDiasSel) + diasSeleccionados(diasSelected);
            diasTexto.setText(text_show);

        };


        noDate.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){

                if (isChecked){
                    fechaInicio=99999999;
                    fechaFin=99999999;

                    txtfechaInicio.setText(getString(R.string.txtnoDate));
                    txtfechaFin.setText(getString(R.string.txtnoDate));
                }else{txtfechaInicio.setText("");
                    txtfechaFin.setText("");
                    fechaInicio=-1;
                    fechaFin=-1;
                };
            };
        });
        Calendar calendar = Calendar.getInstance();
        year = (int) calendar.get(Calendar.YEAR);
        month = (int) calendar.get(Calendar.MONTH);
        day = (int) calendar.get(Calendar.DAY_OF_MONTH);

        dias2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alertDialogBuilder = new
                        AlertDialog.Builder(context);


                alertDialogBuilder.setMultiChoiceItems(arrayDias,arrayCkDias, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {

                        final AbsListView listDias =  (AbsListView) alertDialog.getListView();

                        if (((diasSelected/128)==1) & (which>0) & (!(isChecked))){
                            setDias=128;
                            diasSelected =
                                    diasSelected  & (~setDias);
                            arrayCkDias[0]=false;

                            listDias.setItemChecked(0,false);
                        };
                        switch (which){
                            case 0:
                                if(isChecked){
                                    for(int i=1; i < 8; i++){
                                        listDias.setItemChecked(i,true);
                                        arrayCkDias[i]=true;};
                                    diasSelected = 255;
                                };
                                break;
                            case 1:
                                setDias=1;
                                if(isChecked){
                                    diasSelected= diasSelected | setDias;
                                }
                                else
                                {
                                    diasSelected =
                                            diasSelected  & (~setDias);
                                };
                                break;
                            case 2:
                                setDias=2;
                                if(isChecked) {
                                    diasSelected= diasSelected | setDias;
                                }
                                else
                                {diasSelected =
                                        diasSelected  & (~setDias);
                                };
                                break;
                            case 3:
                                setDias=4;
                                if(isChecked){
                                    diasSelected=
                                            diasSelected | setDias;

                                }
                                else{
                                    diasSelected =
                                            diasSelected  & (~setDias);
                                };
                                break;
                            case 4:
                                setDias=8;
                                if(isChecked){
                                    diasSelected=
                                            diasSelected | setDias;
                                }
                                else{
                                    diasSelected =
                                            diasSelected  & (~setDias);
                                };
                                break;
                            case 5:
                                setDias=16;
                                if(isChecked){
                                    diasSelected =
                                            diasSelected | setDias;
                                }
                                else
                                {diasSelected =
                                        diasSelected  & (~setDias);
                                };
                                break;
                            case 6:
                                setDias=32;
                                if(isChecked){
                                    diasSelected= diasSelected | setDias;
                                }
                                else{diasSelected =
                                        diasSelected  & (~setDias);
                                };
                                break;
                            case 7:

                                setDias=64;
                                if(isChecked){
                                    diasSelected= diasSelected | setDias;
                                }
                                else{
                                    diasSelected =
                                            diasSelected  & (~setDias);
                                };
                                break;
                        };
                    }
                });

                alertDialogBuilder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        String text_show = getString(R.string.txtDiasSel) + diasSeleccionados(diasSelected);
                        diasTexto.setText(text_show);
                        alertDialog.dismiss();
                    }
                });
                alertDialogBuilder.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {

                        final AbsListView listDias =  (AbsListView) alertDialog.getListView();
                        diasTexto.setText(" ");
                        for(int i=0; i < 8; i++){
                            listDias.setItemChecked(i,false);
                            arrayCkDias[i]=false;};
                        diasSelected=0;
                        alertDialog.dismiss();
             }
                });
              alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });
        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final int activado = 1;
                final int andOr=-1;
//public DatosArduinoT(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2)
                boolean check =(fechaInicio>0)&(fechaFin>0)&(tiempoRiego1>0)&(horaRiego1>0)&(diasSelected>0);
                if ((unRiego.isChecked()& check)){
                    DatosArduinoT data = new DatosArduinoT(activado,andOr,fechaInicio , fechaFin,tiempoRiego1,diasSelected ,horaRiego1, horaRiego2, tiempoRiego2);
                    MainActivity.allData.programaSolenoideT(data, nroSolenoide);
                    Toast.makeText(context,getString(R.string.stToast6),Toast.LENGTH_SHORT).show();}
                    else if(!(unRiego.isChecked()& check & (tiempoRiego2>0) & (horaRiego2>0) )){
                        DatosArduinoT data = new DatosArduinoT(activado,andOr,fechaInicio , fechaFin,tiempoRiego1,diasSelected ,horaRiego1, horaRiego2, tiempoRiego2);
                    MainActivity.allData.programaSolenoideT(data, nroSolenoide);
                    Toast.makeText(context,getString(R.string.stToast6),Toast.LENGTH_SHORT).show();}
                else{
                    Toast.makeText(context,getString(R.string.stToast7),Toast.LENGTH_SHORT).show();
                }

            }});


        dPickInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            if (noDate.isChecked()){fechaInicio=99999999;
                fechaFin=99999999;
                txtfechaInicio.setText(getString(R.string.txtnoDate));
                txtfechaFin.setText(getString(R.string.txtnoDate));}
            else{
                showDialog(999);
                Toast.makeText(context,getString(R.string.stToast),Toast.LENGTH_SHORT).show();
                datatoiniciofin =1;
            }}});

        dPickFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            if (!(noDate.isChecked())){
                showDialog(999);
                Toast.makeText(context,getString(R.string.stToast),Toast.LENGTH_SHORT).show();
                datatoiniciofin=2;}

            else{fechaInicio=99999999;
                fechaFin=99999999;
                txtfechaInicio.setText(getString(R.string.txtnoDate));
                txtfechaFin.setText(getString(R.string.txtnoDate));
            };

        }});


        unRiego.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){

                if (isChecked){
                    tiempoRiego2=0;
                    horaRiego2 =99999999;
                    txtHoraRiego2.setText(R.string.unRiego);
                    txtTiempo2.setText(R.string.unRiego);
                }else{txtHoraRiego2.setText("");
                    txtTiempo2.setText("");
            tiempoRiego2=-1;
            horaRiego2 =-1;}
        }});

        pkHoraRiego1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            showDialog(888);
            Toast.makeText(context,getString(R.string.stToast2),Toast.LENGTH_SHORT).show();
            datatoiniciofint =1;

        }});

        tiempo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            Toast.makeText(context,getString(R.string.stToast3),Toast.LENGTH_SHORT).show();


            final Dialog dialog = new Dialog(context);

            dialog.setContentView(R.layout.timer);

            dialog.setTitle(getString(R.string.txtdialogTimer));

            final NumberPicker numberpicker = (NumberPicker) dialog.findViewById(R.id.numberpicker);

            numberpicker.setWrapSelectorWheel(true);
            numberpicker.setMinValue(1);
            numberpicker.setMaxValue(180);

            final Button ok1 = (Button) dialog.findViewById(R.id.ok1);

            ok1.setOnClickListener( new OnClickListener(){
                @Override
                public void onClick(View view){
                    if (numberpicker.getValue()>0){
                        if(horaRiego1==horaRiego2) {

                            tiempoRiego2 = numberpicker.getValue();
                            tiempoRiego1 = numberpicker.getValue();
                            maketimertext2(tiempoRiego2);
                            maketimertext1(tiempoRiego1);
                        };
                        tiempoRiego1 = numberpicker.getValue();
                        Toast.makeText(context,getString(R.string.stToast5),Toast.LENGTH_SHORT).show();
                        maketimertext1(tiempoRiego1);
                        dialog.dismiss();};
                }
            });

            final Button cancel1 = (Button) dialog.findViewById(R.id.cancel1);

            cancel1.setOnClickListener( new OnClickListener(){
                @Override
                public void onClick(View view){
                    dialog.cancel();
                }
            });

            dialog.show();

        }});


        pkHoraRiego2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!(unRiego.isChecked())){

                showDialog(888);
                Toast.makeText(context,getString(R.string.stToast2),Toast.LENGTH_SHORT).show();
                datatoiniciofint=2;

            }}});

        tiempo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!(unRiego.isChecked())){
            Toast.makeText(context,getString(R.string.stToast3),Toast.LENGTH_SHORT).show();

            final Dialog dialog = new Dialog(context);

            dialog.setContentView(R.layout.timer);

            dialog.setTitle(getString(R.string.txtdialogTimer));

            final NumberPicker numberpicker = (NumberPicker) dialog.findViewById(R.id.numberpicker);

            numberpicker.setWrapSelectorWheel(true);
            numberpicker.setMinValue(1);
            numberpicker.setMaxValue(180);

            final Button ok1 = (Button) dialog.findViewById(R.id.ok1);

            ok1.setOnClickListener( new OnClickListener(){
                @Override
                public void onClick(View view){
                    if (numberpicker.getValue()>0){
                        if(horaRiego1==horaRiego2) {

                            tiempoRiego2 = numberpicker.getValue();
                            tiempoRiego1 = numberpicker.getValue();
                            maketimertext2(tiempoRiego2);
                            maketimertext1(tiempoRiego1);
                        };
                        tiempoRiego2 = numberpicker.getValue();
                        Toast.makeText(context,getString(R.string.stToast5),Toast.LENGTH_SHORT).show();
                        maketimertext2(tiempoRiego2);
                        dialog.dismiss();};
                }
            });

            final Button cancel1 = (Button) dialog.findViewById(R.id.cancel1);

            cancel1.setOnClickListener( new OnClickListener(){
                @Override
                public void onClick(View view){
                    dialog.cancel();
                }
            });

            dialog.show();

        }}});

        return root;
    };

    private String diasSeleccionados(int diasSelected) {
        String txtDiasSelected;

        if ((diasSelected/128)==1){
            txtDiasSelected= arrayDias[0];
        }
        else{
            StringBuilder builDias =
                    new StringBuilder();
            for (int i = 0; i < 7; i++){
                int diasselector=diasSelected & (int)(Math.pow((double)2,(double)i));
                int bitOn = diasselector >> i;
                if (bitOn==1){ builDias.append(arrayDias[i+1]).append("  ");
                };
            };
         txtDiasSelected = builDias.toString();
        };
        return txtDiasSelected;
    };

    private void showDialog(int id) {
        onCreateDialog(id).show();
    }
    private Dialog onCreateDialog(int id)
    {
        switch (id){

            case 999:

                DatePickerDialog d = new DatePickerDialog(context,AlertDialog.THEME_DEVICE_DEFAULT_DARK, myDateListener, year, month, day);
                d.setTitle(getString(R.string.txtdialogDate));
                return d;

            case 888:
                Calendar time =
                        Calendar.getInstance();
                hora = (int) time.get(Calendar.HOUR_OF_DAY);
                minuto = (int) time.get(Calendar.MINUTE);

                TimePickerDialog t = new TimePickerDialog
                        (context,myTimeListener,hora, minuto, false);
                t.setTitle(getString(R.string.txtdialogTime));
                return t;

            default: return null;

        }
    };

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener()
            {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {

                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    int returnFecha;

                    int dateNow = (year*10000)+((month+1)*100)+day;

                    int dateSelec = (arg1*10000)+((arg2+1)*100)+arg3;

                    if (dateSelec > dateNow) {

                        returnFecha= dateSelec;
                    }
                    else {
                        returnFecha = dateNow;
                        Toast.makeText(context,getString(R.string.stToast4),Toast.LENGTH_SHORT).show();
                    };

                    switch (datatoiniciofin){
                        case 1:
                            if(fechaFin<returnFecha){
                                fechaFin=returnFecha;
                                fechaInicio=returnFecha;
                                Toast.makeText(context,getString(R.string.stToast4),Toast.LENGTH_SHORT).show();
                            }
                            else{
                                fechaInicio=returnFecha;
                                Toast.makeText(context,getString(R.string.stToast5),Toast.LENGTH_SHORT).show();
                            }
                            break;


                        case 2:
                            if(fechaInicio<returnFecha){
                                fechaFin=returnFecha;
                                Toast.makeText(context,getString(R.string.stToast5),Toast.LENGTH_SHORT).show();
                            }
                            else {fechaFin=fechaInicio;
                                Toast.makeText(context,getString(R.string.stToast4),Toast.LENGTH_SHORT).show();
                            }
                            break;
                    };
                    makeintdate(txtfechaInicio, fechaInicio);
                    makeintdate(txtfechaFin,fechaFin);
                };
            };


    private void makeintdate(TextView v,int a){
        if (a>0){
            int y = a/10000;
            int m = (a-(y*10000))/100;
            int d = (a-(y*10000+m*100));
            StringBuilder b = new StringBuilder().
                    append(y).
                    append("/").
                    append(m).
                    append("/").
                    append(d);
            v.setText(b);
        };


    };


    private TimePickerDialog.OnTimeSetListener myTimeListener = new TimePickerDialog.OnTimeSetListener(){
        @Override
        public void onTimeSet(TimePicker arg0,
                              int arg1, int arg2) {
            // TODO Auto-generated method stub
            // arg1 = hora
            // arg2 = minuto
            int returnHora= (arg1*100)+arg2;
            Toast.makeText(context,getString(R.string.stToast),Toast.LENGTH_SHORT).show();

            switch (datatoiniciofint){
                case 1:
                    if(horaRiego2<returnHora){
                        horaRiego2=returnHora;
                        horaRiego1=returnHora;
                        Toast.makeText(context,getString(R.string.stToast4),Toast.LENGTH_SHORT).show();
                    }
                    else{
                        horaRiego1=returnHora;
                        Toast.makeText(context,getString(R.string.stToast5),Toast.LENGTH_SHORT).show();
                    }
                    break;


                case 2:
                    if(horaRiego1<returnHora){
                        horaRiego2=returnHora;
                        Toast.makeText(context,getString(R.string.stToast5),Toast.LENGTH_SHORT).show();

                    }
                    else

                    {horaRiego2 = horaRiego1;
                        Toast.makeText(context,getString(R.string.stToast4),Toast.LENGTH_SHORT).show();
                    };
                    break;
            };

            makeinttime(txtHoraRiego1,horaRiego1);
            makeinttime(txtHoraRiego2,horaRiego2);
        };
    };


    private void makeinttime(TextView v,int a){

        int h =a/100;
        int m = (a-(h*100));
        StringBuilder b = new StringBuilder().
                append("(H:M)24hrs").
                append(h).
                append(":").
                append(m);
        v.setText(b);

    };


    private void maketimertext1(int t){

        StringBuilder txt = new  StringBuilder().append(t).append(" Min.");
        txtTiempo1.setText(txt);
    };


    private void maketimertext2(int t){

        StringBuilder txt = new  StringBuilder().append(t).append(" Min.");
        txtTiempo2.setText(txt);
    };

}



