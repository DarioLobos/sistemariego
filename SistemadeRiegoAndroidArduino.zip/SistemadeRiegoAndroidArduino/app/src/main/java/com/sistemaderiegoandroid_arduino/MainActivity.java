package com.sistemaderiegoandroid_arduino;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.DocumentsProvider;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.sistemaderiegoandroid_arduino.ui.Resumen.ResumenFragment;

import java.io.FileNotFoundException;

import static android.provider.DocumentsContract.buildRootUri;
import static com.sistemaderiegoandroid_arduino.MyDocuments.AUTORITY;
import static com.sistemaderiegoandroid_arduino.MyDocuments.ROOT;
import static com.sistemaderiegoandroid_arduino.ui.Resumen.ResumenFragment.errorMsg;

public class MainActivity extends AppCompatActivity {
    //MainActivity(){};

    public static Data allData = new Data();
    public static int repeat_to_quit = 0;
    private static int callBackFlag = 0;
    boolean grantRequested = false;
    private Context context;
    private AppBarConfiguration mAppBarConfiguration;
    private String permitHandling;
    private String exit;
    private String grantDialog;
    private String quit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Context context = this;


        Data.arrayDias = new String[]{getString(R.string.todosDias),
                getString(R.string.lunes),
                getString(R.string.martes),
                getString(R.string.miercoles),
                getString(R.string.jueves),
                getString(R.string.viernes),
                getString(R.string.Sabado),
                getString(R.string.Domingo)};

        Data.error_save = getString(R.string.error_save_empty);
        ;
        quit = getString(R.string.quit);

        MyDocuments.falloBorrar = getString(R.string.falloBorrar);
        MyDocuments.falloConsulta = getString(R.string.falloConsulta);
        MyDocuments.falloGrabar = getString(R.string.falloGrabar);
        MyDocuments.falloCrear = getString(R.string.falloCrear);
        permitHandling = getString(R.string.permitsHandling);
        exit = getString(R.string.exit);
        grantDialog = getString(R.string.grantDialog);
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Navigation.findNavController(MainActivity.this, R.id.nav_host_fragment).navigate(R.id.action_global_nav_home);

            }
        });


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_riegoT, R.id.nav_riegoH,
                R.id.nav_riegoL, R.id.nav_riegoM, R.id.nav_arduino, R.id.nav_resumen)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        int granted = PackageManager.PERMISSION_GRANTED;

        grantRequested =
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != granted |
                        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != granted |
                        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) != granted |
                        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADMIN) != granted;

        if ((grantRequested)) {


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if ((!Settings.System.canWrite(this))) {

                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                    alertDialogBuilder.setTitle(grantDialog).setMessage(R.string.requestWriteSetting);
                    alertDialogBuilder.setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int id) {
                                    if (callBackFlag == 0) {
                                        dialog.dismiss();
                                        Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                                        intent.setData(Uri.parse("package:com.sistemaderiegoandroid_arduino"));

                                        startActivity(intent);
                                        callBackFlag++;
                                        int granted = PackageManager.PERMISSION_GRANTED;

                                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_SETTINGS)!= granted) {

                                                grantRequested =
                                                        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != granted |
                                                                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != granted |
                                                                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) != granted |
                                                                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADMIN) != granted;
                                                if (grantRequested) {

                                                    ActivityCompat.requestPermissions(MainActivity.this,
                                                            new String[]{
                                                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                                                    Manifest.permission.READ_EXTERNAL_STORAGE,
                                                                    Manifest.permission.BLUETOOTH,
                                                                    Manifest.permission.BLUETOOTH_ADMIN}, RESULT_OK);


                                                } else {
                                                    if (grantRequested) {

                                                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                                                        alertDialogBuilder.setTitle(exit).setMessage(R.string.permitNotGranted);
                                                        alertDialogBuilder.setCancelable(false)
                                                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                                    public void onClick(DialogInterface dialog, int id) {

                                                                        MainActivity.this.finish();
                                                                        System.exit(0);
                                                                    }
                                                                });


                                                        AlertDialog alertDialog = alertDialogBuilder.create();
                                                        alertDialog.show();

                                                    }
                                                }
                                            }
                                    } else {
                                        dialog.dismiss();

                                        alertDialogBuilder.setTitle(exit).setMessage(R.string.permitNotGranted);
                                        alertDialogBuilder.setCancelable(false)
                                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {

                                                        MainActivity.this.finish();
                                                        System.exit(0);
                                                    }
                                                });


                                        AlertDialog alertDialog = alertDialogBuilder.create();
                                        alertDialog.show();

                                    }
                                }

                            });

                }
            }else{ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.BLUETOOTH,
                            Manifest.permission.BLUETOOTH_ADMIN}, RESULT_OK);}
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean grantChecker = false;


        if (grantResults.length > 0) {
            grantChecker = true;

            for (int i = 0; grantResults.length > i; i++) {
                boolean a = grantResults[i] == PackageManager.PERMISSION_GRANTED;
                grantChecker = grantChecker & a;
            }
        }

        if (requestCode != RESULT_OK) {

            int granted = PackageManager.PERMISSION_GRANTED;

            if (!grantChecker & (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_SETTINGS) == granted)) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    errorMsg(permitHandling);
                    ActivityCompat.requestPermissions(this,
                            new String[]{
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.READ_EXTERNAL_STORAGE,
                                    Manifest.permission.BLUETOOTH,
                                    Manifest.permission.BLUETOOTH_ADMIN}, RESULT_OK);

                } else {

                    grantRequested =
                            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != granted |
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) != granted |
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) != granted |
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADMIN) != granted;

                    if (grantRequested) {

                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


                        alertDialogBuilder.setTitle(exit).setMessage(R.string.permitNotGranted);
                        alertDialogBuilder.setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        MainActivity.this.finish();
                                        System.exit(0);
                                    }
                                });


                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();

                    }
                    ;
                }

            }
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case (R.id.ayuda):
                Toast.makeText(context, "Ayuda en construccion", Toast.LENGTH_SHORT).show();
                break;


            case (R.id.instalacion):
                Toast.makeText(context, "Instalacion en construccion", Toast.LENGTH_SHORT).show();
                break;


            case (R.id.configuracion):
                Toast.makeText(context, "Congfiguracion en construccion", Toast.LENGTH_SHORT).show();
                Navigation.findNavController(this, R.id.nav_host_fragment).navigate(R.id.action_global_nav_arduino);

                break;

            case (R.id.acercade):
                Toast.makeText(context, "Acerca de en construccion", Toast.LENGTH_SHORT).show();
                break;
        }

        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBackPressed() {
        FragmentManager fragmentManager = super.getSupportFragmentManager();
        final boolean isStateSaved = fragmentManager.isStateSaved();
        if (isStateSaved && Build.VERSION.SDK_INT <= Build.VERSION_CODES.N_MR1) {
            // Older versions will throw an exception from the framework
            // FragmentManager.popBackStackImmediate(), so we'll just
            // return here. The Activity is likely already on its way out
            // since the fragmentManager has already been saved.
            return;
        }

        if (!isTaskRoot()) {
            super.onBackPressed();
        } else {

            Toast.makeText(context, quit, Toast.LENGTH_SHORT).show();

            if (repeat_to_quit > 0) {
                repeat_to_quit = 0;

                super.onBackPressed();
            }
            repeat_to_quit = +1;
        }

    }


    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    ;



};

