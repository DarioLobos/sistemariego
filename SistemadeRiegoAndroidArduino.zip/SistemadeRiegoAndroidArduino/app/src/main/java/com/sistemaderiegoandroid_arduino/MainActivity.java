package com.sistemaderiegoandroid_arduino;

import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import android.view.MenuItem;
import android.view.View;
import android.content.Context;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //MainActivity(){};
    public static Data allData = new Data();
    private Context context;
    private AppBarConfiguration mAppBarConfiguration;
    private boolean onCreateFlag = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        Data.arrayDias = new String[]{getString(R.string.todosDias),
                getString(R.string.lunes),
                getString(R.string.martes),
                getString(R.string.miercoles),
                getString(R.string.jueves),
                getString(R.string.viernes),
                getString(R.string.Sabado),
                getString(R.string.Domingo)};

     Data.error_save = getString(R.string.error_save_empty);;

        onCreateFlag = true;
        setContentView(R.layout.activity_main);
        context= this;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                      PopupMenu popup = new PopupMenu(context,fab);
                popup.getMenuInflater().inflate(R.menu.main, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch(item.getItemId()){

                            case (R.id.espanol):
                                Toast.makeText(context, "Lenguaje seleccionado Espanol", Toast.LENGTH_SHORT).show();
                                break;


                            case (R.id.english):
                                Toast.makeText(context, "Language selected English", Toast.LENGTH_SHORT).show();
                                break;

                            case (R.id.portugues):
                                Toast.makeText(context, "Lenguaje seleccionado Portuges", Toast.LENGTH_SHORT).show();
                                break;}
                        return true;
                    }
                });

                popup.show();//showing popup menu
                Snackbar.make(view, "<<<<<<<>>>>>>>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

           }
});


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_riegoT, R.id.nav_riegoH,
                R.id.nav_riegoL, R.id.nav_riegoM, R.id.nav_arduino,R.id.nav_resumen)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);


        context = this;


    }





        @Override
    public boolean onCreateOptionsMenu (Menu menu){
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
   @Override
    public boolean onOptionsItemSelected (MenuItem item){
        context =this;
        switch (item.getItemId()) {

            case (R.id.espanol):
                Toast.makeText(context, "Lenguaje seleccionado Espanol", Toast.LENGTH_SHORT).show();
                break;


            case (R.id.english):
                Toast.makeText(context, "Language selected English", Toast.LENGTH_SHORT).show();
                break;

            case (R.id.portugues):
                Toast.makeText(context, "Lenguaje seleccionado Portuges", Toast.LENGTH_SHORT).show();
                break;

        }
        ;
        return true;
    };





    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    };

};

