package com.sistemaderiegoandroid_arduino;


public class DatosArduinoT extends DatosArduino{
    private static final long  serialVersionUID=8L;
    public int horainicio1;
    public int horainicio2;
    public int tiemporiego2;





    public DatosArduinoT(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2){
        super(activado,andOr,fechainicio,fechafin,tiemporiego1,diasSemana);
        this.horainicio1=horainicio1;
        this.horainicio2=horainicio2;
        this.tiemporiego2=tiemporiego2;
    };

    public int getHoraInicio1(){
        return this.horainicio1;
    };
    public int getHoraInicio2(){
        return this.horainicio2;
    };

    public int getTiempoRiego2(){
        return this.tiemporiego2;
    };
    @Override
    public void setAndOr(int andOr){
        this.andOr = andOr;
    };

    @Override
    public int getFechaInicio(){
        return this.fechainicio;
    };

    @Override
    public int getFechaFin(){
        return this.fechafin;
    };

    @Override
    public int getActivado(){
        return this.activado;
    };

    @Override
    public int getTiempoRiego1(){
        return this.tiemporiego1;
    };

    @Override
    public int getDiasSemana(){
        return this.diasSemana;
    };

    @Override
    public void setActivado(int activado){
        this.activado = activado;
    };

    @Override
    public int getAndOr(){
        return this.andOr;
    }
    public static void main(String[] args){








    }
}