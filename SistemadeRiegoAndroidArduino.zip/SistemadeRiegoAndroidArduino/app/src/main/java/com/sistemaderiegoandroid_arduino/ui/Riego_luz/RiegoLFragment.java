package com.sistemaderiegoandroid_arduino.ui.Riego_luz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.content.Intent;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.sistemaderiegoandroid_arduino.R;
import com.sistemaderiegoandroid_arduino.SoleLuz;

public class RiegoLFragment extends Fragment {
    private Context context;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        final View root = inflater.inflate(R.layout.riegoluz, container, false);
        context = root.getContext();

        final TextView titulo = root.findViewById(R.id.titulo);
        final TextView riegoL = root.findViewById(R.id.riegoL);
        String [] solenoide = new String []{getString(R.string.psolenoide1),getString(R.string.psolenoide2),getString(R.string.psolenoide3),getString(R.string.psolenoide4), getString(R.string.psolenoide5),getString(R.string.psolenoide6)};



        ArrayAdapter<String> adapSolenoide = new ArrayAdapter<String>(root.getContext(), android.R.layout.simple_list_item_activated_1, solenoide);

        ListView solenoides = (ListView) root.findViewById(R.id.solenoides);

        solenoides.setAdapter(adapSolenoide);


        solenoides.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> a,View v, int position, long id) {
                Bundle solenoide_nro = new Bundle();
                solenoide_nro.putInt("nrosolenoide",position);
                Navigation.findNavController(root).navigate(R.id.action_nav_riegoL_to_nav_soleluz,solenoide_nro);
            };
        });
return root;

    };
}