package com.sistemaderiegoandroid_arduino.ui.Resumen;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.ContactsContract;
import android.provider.DocumentsProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.provider.DocumentsContract;
import android.app.Activity;

import androidx.core.content.FileProvider;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.sistemaderiegoandroid_arduino.AdaptadorResumen;
import com.sistemaderiegoandroid_arduino.Data;
import com.sistemaderiegoandroid_arduino.DatosArduinoRString;
import com.sistemaderiegoandroid_arduino.MainActivity;
import com.sistemaderiegoandroid_arduino.MyDocuments;
import com.sistemaderiegoandroid_arduino.R;

import java.io.File;
import java.io.IOException;
import java.security.Provider;
import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;
import static android.content.Intent.ACTION_CREATE_DOCUMENT;
import static android.content.Intent.ACTION_OPEN_DOCUMENT;
import static android.content.Intent.ACTION_OPEN_DOCUMENT_TREE;
import static android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION;
import static android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
import static android.content.Intent.getIntentOld;
import static android.os.Environment.*;
import static android.provider.DocumentsContract.ACTION_DOCUMENT_SETTINGS;
import static android.provider.DocumentsContract.findDocumentPath;
import static androidx.core.content.FileProvider.*;
import static com.sistemaderiegoandroid_arduino.Data.error_save;
import static com.sistemaderiegoandroid_arduino.Data.fileNameH;
import static com.sistemaderiegoandroid_arduino.Data.fileNameL;
import static com.sistemaderiegoandroid_arduino.Data.fileNameR;
import static com.sistemaderiegoandroid_arduino.Data.fileNameT;
import static com.sistemaderiegoandroid_arduino.MainActivity.*;
import static com.sistemaderiegoandroid_arduino.MyDocuments.AUTORITY;
import static com.sistemaderiegoandroid_arduino.MyDocuments.DEFAULT_DOCUMENT_PROJECTION;
import static com.sistemaderiegoandroid_arduino.MyDocuments.EMPTY;
import static com.sistemaderiegoandroid_arduino.MyDocuments.ROOT;
import static com.sistemaderiegoandroid_arduino.MyDocuments.falloBorrar;

public class ResumenFragment extends Fragment {
    private EditText path;
    public static Context context;
    private int path_opcion;

    private static String stToast11;
    private static String stToast12;
    private static String stToast13;
    private static String stToast14;
    private static String stToast15;
    private static String pathTitle;
    private static String bluetoothOn;
    public static Uri fileUri;
    private Uri fileUriL;
    public static File file;
    public static int activadoT = 0;
    public static int activadoL = 0;
    public static int activadoH = 0;
    private static String StfileR = "arduino_data_resumen.bin";
    private static String StfileT = "arduino_data_tiempo.bin";
    private static String StfileH = "arduino_data_humedad.bin";
    private static String StfileL = "arduino_data_luz.bin";
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.resumen, container, false);

        context = root.getContext();

        Uri parent = DocumentsContract.buildRootUri(AUTORITY, ROOT);

        Uri rootUri = null;
       if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {

            try {
                DocumentsContract.createDocument(context.getContentResolver(), parent, DocumentsContract.Document.MIME_TYPE_DIR, ROOT);

            } catch (FileNotFoundException e) {
                errorMsg(e.toString());
           }
        }
        rootUri = DocumentsContract.buildDocumentUri(AUTORITY, ROOT);

        //      ContentObserver observer = new ContentObserver(null) {
        //          @Override
        //                    public boolean deliverSelfNotifications() {
        //                         return super.deliverSelfNotifications();
        //                    }
        //                };

        //      context.getContentResolver().notifyChange(rootUri,observer);
        //      context.getContentResolver().registerContentObserver(rootUri,true,observer);
        //      observer.dispatchChange(true,rootUri);

        // Uri documentsInRoot = DocumentsContract.buildChildDocumentsUri(AUTORITY,ROOT);

        Cursor cursorDocuments = context.getContentResolver().query(rootUri, DEFAULT_DOCUMENT_PROJECTION, "", new String[]{""}, "asc");
        if (cursorDocuments != null) {
            cursorDocuments.moveToFirst();
            int index = cursorDocuments.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            String document_Id = "";
            while (cursorDocuments.moveToNext()) {
                if (!cursorDocuments.isNull(index)) {
                    document_Id = cursorDocuments.getString(index);
                    Uri document_uri = DocumentsContract.buildDocumentUri(AUTORITY, document_Id);
                    context.getContentResolver().notifyChange(document_uri, null);
                }
            }
            cursorDocuments.close();
        }

        //       if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        //           contextObserver.getContentResolver().refresh(rootUri,null,null);
        //       }

        stToast11 = getString(R.string.stToast11);
        stToast12 = getString(R.string.stToast12);
        stToast13 = getString(R.string.stToast13);
        stToast14 = getString(R.string.stToast14);
        stToast15 = getString(R.string.stToast15);
        pathTitle = getString(R.string.PathTitle);
        bluetoothOn = getString(R.string.bluetoothOn);


        final TextView titulo =
                root.findViewById(R.id.titulo);
        final TextView resumen = root.findViewById(R.id.resumen);
        final Button archivo = (Button) root.findViewById(R.id.archivo);
        final Button arduino = (Button) root.findViewById(R.id.arduino);

        final ListView ListaResumen = root.findViewById(R.id.ListaResumen);

        archivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popup = new PopupMenu(context, archivo);
                popup.getMenuInflater().inflate(R.menu.popuparchivo, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()) {
                            case (R.id.save):
                                saveData(context);
                                break;
                            case (R.id.read):
                                loadData(context);
                                break;
                            case (R.id.path):
                                ResumenFragment path = new ResumenFragment();
                                path.path();
                                break;
                        }
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });

        arduino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popup = new PopupMenu(context, archivo);
                popup.getMenuInflater().inflate(R.menu.popuparchivo, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()) {
                            case (R.id.bluetoothOn):
                                final BluetoothAdapter bAdapter = BluetoothAdapter.getDefaultAdapter();
                                if (bAdapter == null) {
                                    Toast.makeText(context, stToast13, Toast.LENGTH_SHORT).show();
                                } else {
                                    if (!bAdapter.isEnabled()) {
                                        try {
                                            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 1);
                                            Toast.makeText(context, bluetoothOn, Toast.LENGTH_SHORT).show();
                                        } catch (Exception e) {
                                            errorMsg(e.toString());
                                        }
                                    }
                                }
                            case (R.id.emparejar):
                                Toast.makeText(context, "You Clicked : " + item.getTitle(), Toast.LENGTH_SHORT).show();
                            case (R.id.path):
                        }
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });
        ArrayList<DatosArduinoRString> lista =
                new ArrayList<DatosArduinoRString>();
        lista = (ArrayList<DatosArduinoRString>) allData.FabricaResumen();
        AdaptadorResumen adaptador = new AdaptadorResumen(context, lista);
        ListaResumen.setAdapter(adaptador);
        return root;
    }

    public static void toastsave() {
        Toast.makeText(context, stToast12, Toast.LENGTH_SHORT).show();
    }

    public static void toastnotsave() {
        Toast.makeText(context, stToast11, Toast.LENGTH_SHORT).show();
    }

    public static void toastread() {
        Toast.makeText(context, stToast14, Toast.LENGTH_SHORT).show();
    }

    public static void toastnotread() {
        Toast.makeText(context, stToast15, Toast.LENGTH_SHORT).show();
    }

    public static void errorMsg(String e) {
        final AlertDialog.Builder alertDialogBuilder = new
                AlertDialog.Builder(context);

        alertDialogBuilder.setMessage("Error: " + e)
                .setCancelable(false)
                .setPositiveButton("???", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();

    }

    public int path() {

        LayoutInflater li = LayoutInflater.from(context);
        View promptsView = li.inflate(R.layout.pathtext, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


        alertDialogBuilder.setTitle(pathTitle);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        LayoutInflater li = LayoutInflater.from(context);
                        View promptsView = li.inflate(R.layout.pathtext, null);

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


                        alertDialogBuilder.setTitle(pathTitle);

                        alertDialogBuilder.setMessage(pathTitle + " " + Data.dirpath);
                        alertDialogBuilder.setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.dismiss();
                                    }
                                });

                        AlertDialog alertDialog = alertDialogBuilder.create();

                        alertDialog.show();

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
        return path_opcion;

    }

    ;

    private void saveData(Context context) {
        activadoT = 0;
        activadoL = 0;
        activadoH = 0;

        if (allData.arrayDatosTiempo != null) {
            for (int i = 0; i < allData.arrayDatosTiempo.length; i++) {
                if (Data.arrayDatosTiempo[i].getActivado() == 1) {
                    activadoT = 1;
                }
            }
        }
        ;
        if (allData.arrayDatosHumedad != null) {
            for (int i = 0; i < allData.arrayDatosHumedad.length; i++) {
                if (Data.arrayDatosHumedad[i].getActivado() == 1) {
                    activadoH = 1;
                }
            }
            ;
        }
        ;
        if (allData.arrayDatosLuz != null) {
            for (int i = 0; i < allData.arrayDatosLuz.length; i++) {
                if (Data.arrayDatosLuz[i].getActivado() == 1) {
                    activadoL = 1;
                }
            }
            ;
        }
        ;

        if (activadoH == 1 | activadoL == 1 | activadoT == 1) {

            String a = getExternalStorageDirectory().getPath();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                try {

                    String public_dir = "sistemaderiegoandroid_arduino" + MyDocuments.fileSeparator;
                    file = new File(a, public_dir);

                    file.setWritable(true);

                    if (!file.mkdirs()) {

                        file.mkdir();
                    }
                    ;
                    DocumentsContract.createDocument(context.getContentResolver(), DocumentsContract.buildRootUri(AUTORITY, ROOT), DocumentsContract.Document.MIME_TYPE_DIR, MyDocuments.INITIALURI);
                    fileUri = DocumentsContract.buildDocumentUri(AUTORITY, MyDocuments.INITIALURI);

                } catch (Exception e) {
                    errorMsg("mkdir" + MyDocuments.falloCrear + e.toString());
                }
            } else {
                file = Environment.getExternalStorageDirectory();

                file.setWritable(true);
            }
            ;


            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


            alertDialogBuilder.setTitle(context.getString(R.string.saveTitle));

            alertDialogBuilder.setMessage(context.getString(R.string.alertSave));
            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();


                                    loopSave();


                                }


                            }
                    );

            AlertDialog alertDialog = alertDialogBuilder.create();

            alertDialog.show();


        } else {
            errorMsg(error_save);

        }

    }

    private void loopSave(){
        Boolean finish=false;

        for (int i = 1; i < 5; i++) {

            finish = whileSave(i);

            while (!finish) {
            };

        }
    }
    private static final int CREATE_FILE_R = 1;
    private static final int CREATE_FILE_T = 2;
    private static final int CREATE_FILE_H = 3;
    private static final int CREATE_FILE_L = 4;

    private static final int PICK_FILE_R = 5;
    private static final int PICK_FILE_T = 6;
    private static final int PICK_FILE_H = 7;
    private static final int PICK_FILE_L = 8;

private  Boolean whileSave(int i){
    Boolean finish=false;
    String fileName = "";
    switch (i) {
        case 1:
            fileName = StfileR;
            break;
        case 2:
            fileName = StfileT;
            break;
        case 3:
            fileName = StfileH;
            break;
        case 4:
            fileName = StfileL;
            break;
    }

    finish = createFile(fileUri, fileName, i);

    while (!finish){};

return true;
    }

    private Boolean createFile(Uri pickerInitialUri, String file_name, int result_option_Flag) {

        //DocumentsUI
        Intent intent = new Intent(ACTION_CREATE_DOCUMENT);
        intent.setType(MyDocuments.MINETYPE);
        intent.putExtra(Intent.EXTRA_TITLE, file_name);
        intent.putExtra(Intent.EXTRA_RETURN_RESULT, RESULT_OK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri);
            intent.putExtra(Intent.EXTRA_RETURN_RESULT, RESULT_OK);
        }

        //    intent.putExtra(DocumentsContract.EXTRA_EXCLUDE_SELF,true);

        startActivityForResult(intent, result_option_Flag);

       return true;
    };


    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {
        if (resultCode == Activity.RESULT_OK) {


            //           The result data contains a URI for the document or directory that
            //           the user selected.
            if (resultData != null) {

                Uri uriData = resultData.getData();
                //   String fileId =DocumentsContract.getDocumentId(uriData);

                switch (requestCode) {

                    case CREATE_FILE_L:
                        Data.fileNameL = uriData;
                        break;
                    case CREATE_FILE_H:
                        Data.fileNameH = uriData;
                        break;
                    case CREATE_FILE_R:
                        Data.fileNameR = uriData;
                        break;
                    case CREATE_FILE_T:
                        fileNameT = uriData;
                        break;

                    case PICK_FILE_R:
                        Data.fileNameR = uriData;


                        openFile(fileUri, PICK_FILE_T);

                        break;

                        case PICK_FILE_T:
                        if (uriData != null) {
                            fileNameT = uriData;
                            AssetFileDescriptor assetFileDescriptorT = null;
                            try {
                                assetFileDescriptorT = context.getContentResolver().openAssetFileDescriptor(uriData, "r", null);
                            } catch (FileNotFoundException e) {
                                errorMsg("ASSET");
                            }

                            if (assetFileDescriptorT != null) {
                                try {
                                    assetFileDescriptorT.getParcelFileDescriptor().close();
                                    assetFileDescriptorT.close();
                                } catch (IOException e) {
                                    errorMsg("ASSETCLOSE");
                                }
                            }
                            ;
                        }
                        errorMsg(fileNameT.getLastPathSegment());

                        openFile(fileUri, PICK_FILE_H);

                        break;

                    case PICK_FILE_H:
                        if (uriData != null) {
                            Data.fileNameH = uriData;
                            AssetFileDescriptor assetFileDescriptorH = null;
                            try {
                                assetFileDescriptorH = context.getContentResolver().openAssetFileDescriptor(uriData, "r", null);
                            } catch (FileNotFoundException e) {
                                errorMsg("ASSET");
                            }

                            if (assetFileDescriptorH != null) {
                                try {
                                    assetFileDescriptorH.getParcelFileDescriptor().close();
                                    assetFileDescriptorH.close();
                                } catch (IOException e) {
                                    errorMsg("ASSETCLOSE");
                                }
                            }

                        }
                        ;
                        errorMsg(fileNameH.getLastPathSegment());

                        openFile(fileUri, PICK_FILE_L);

                        break;

                    case PICK_FILE_L:
                        Data.fileNameL = uriData;
                        if (uriData != null) {
                            AssetFileDescriptor assetFileDescriptorL = null;
                            try {
                                assetFileDescriptorL = context.getContentResolver().openAssetFileDescriptor(uriData, "r", null);
                            } catch (FileNotFoundException e) {
                                errorMsg("ASSET");
                            }

                            if (assetFileDescriptorL != null) {
                                try {
                                    assetFileDescriptorL.getParcelFileDescriptor().close();
                                    assetFileDescriptorL.close();
                                } catch (IOException e) {
                                    errorMsg("ASSETCLOSE");
                                }
                            }
                        }
                        ;
                        errorMsg(fileNameL.getLastPathSegment());


                        break;
                }

                if ((Data.fileNameR != null) & (fileNameT != null) & (Data.fileNameH != null & (Data.fileNameL != null)) & (requestCode < 5)) {

                    final AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(context);

                    alertDialogBuilder2.setTitle(context.getString(R.string.saveTitle));

                    alertDialogBuilder2.setMessage(context.getString(R.string.filesCreated));
                    alertDialogBuilder2.setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                    try {

                                        Data.saveData(context);

                                    } catch (Exception e) {
                                        errorMsg(MyDocuments.falloGrabar + e.toString());
                                    }
                                }
                            });

                    AlertDialog alertDialog2 = alertDialogBuilder2.create();

                    alertDialog2.show();



                }

                if ((Data.fileNameR != null) & (fileNameT != null) & (Data.fileNameH != null & (Data.fileNameL != null)) & (requestCode > 4)) {

                    final AlertDialog.Builder alertDialogBuilder3 = new AlertDialog.Builder(context);

                    alertDialogBuilder3.setTitle(context.getString(R.string.loadData));

                    alertDialogBuilder3.setMessage(context.getString(R.string.filesSelected));
                    alertDialogBuilder3.setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();

                                        Data.loadData(context);

                                }
                            });

                    AlertDialog alertDialog3 = alertDialogBuilder3.create();

                    alertDialog3.show();


                }
            }

        }



    }


    private void loadData(final Context context) {


        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

        alertDialogBuilder.setTitle(context.getString(R.string.loadData));

        alertDialogBuilder.setMessage(context.getString(R.string.loadDialog));
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();


                        openFile(fileUri, PICK_FILE_R);


                        }

                });

        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();


    }

    private void openFile(final Uri pickerInitialUri, final int result_pick_option) {

        String file_name = "";
                 String message = "";

        switch (result_pick_option) {

            case PICK_FILE_R:
                file_name = StfileR;
                message = context.getString(R.string.files_to_load_R) + " " + file_name;

                break;

            case PICK_FILE_T:
                file_name = StfileT;
                message = context.getString(R.string.files_to_load_T) + " " + file_name;

                break;

            case PICK_FILE_H:
                file_name = StfileH;
                message = context.getString(R.string.files_to_load_H) + " " + file_name;

                break;

            case PICK_FILE_L:
                file_name = StfileL;
                message = context.getString(R.string.files_to_load_L) + " " + file_name;

                break;
        }

        final String file_name_alert = file_name;

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setTitle(context.getString(R.string.loadData));
        alertDialogBuilder.setMessage(message);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                        Intent intent = new Intent(ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/bin");
                        intent.putExtra(Intent.EXTRA_TITLE, file_name_alert);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri);
                        }
                        startActivityForResult(intent, result_pick_option);
                    }

                    ;

                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }

    ;
}
