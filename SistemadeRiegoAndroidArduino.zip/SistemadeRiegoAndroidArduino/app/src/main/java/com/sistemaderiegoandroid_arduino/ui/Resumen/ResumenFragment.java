package com.sistemaderiegoandroid_arduino.ui.Resumen;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inspector.StaticInspectionCompanionProvider;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.sistemaderiegoandroid_arduino.AdaptadorResumen;
import com.sistemaderiegoandroid_arduino.Data;
import com.sistemaderiegoandroid_arduino.DatosArduinoRString;
import com.sistemaderiegoandroid_arduino.MainActivity;
import com.sistemaderiegoandroid_arduino.R;
import com.sistemaderiegoandroid_arduino.ui.home.HomeFragment;
import java.util.ArrayList;

public class ResumenFragment extends Fragment {
    private EditText path;
    public static Context context;
    private int path_opcion;

    private String stToast11;
    public String getStToast11(){return this.stToast11;};
    private String stToast12;
    public String getStToast12(){return this.stToast12;};
    private String stToast13;
    public String getStToast13(){return this.stToast13;};
    private String stToast14;
    public String getStToast14(){return this.stToast14;};
    private String stToast15;
    public String getStToast15(){return this.stToast15;};
    private String pathTitle;
    private String privado;
    private String publico;
    private String bluetoothOn;
    ArrayList<DatosArduinoRString> lista =
            new ArrayList<DatosArduinoRString>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.resumen, container, false);

        context = root.getContext();

     stToast11 = getString(R.string.stToast11);
     stToast12 = getString(R.string.stToast12);
     stToast13 = getString(R.string.stToast13);
     stToast14 = getString(R.string.stToast14);
     stToast15 = getString(R.string.stToast15);
     pathTitle = getString(R.string.PathTitle);
        privado = getString(R.string.Privado);
        publico = getString(R.string.Publico);
        bluetoothOn = getString(R.string.bluetoothOn);



        final TextView titulo =
                root.findViewById(R.id.titulo);
        final TextView resumen = root.findViewById(R.id.resumen);
        final Button archivo = (Button) root.findViewById(R.id.archivo);
        final Button arduino = (Button) root.findViewById(R.id.arduino);




        final ListView ListaResumen = root.findViewById(R.id.ListaResumen);



        archivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popup = new PopupMenu(context,archivo);

                popup.getMenuInflater().inflate(R.menu.popuparchivo, popup.getMenu());



                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch(item.getItemId()){


                            case (R.id.save):
                                ResumenFragment save = new ResumenFragment();
                                MainActivity.allData.saveData(context,save.path());

                                break;
                            case(R.id.read):

                                ResumenFragment read = new ResumenFragment();
                                MainActivity.allData.loadData(context,read.path());

                                break;
                            case (R.id.path):
                                ResumenFragment path = new ResumenFragment();
                                path.path();
                                break;
                        }
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }});


        arduino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popup = new PopupMenu(context, arduino);

                popup.getMenuInflater().inflate(R.menu.popuparduino, popup.getMenu());



                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    @Override

                    public boolean onMenuItemClick(MenuItem item) {

                        switch(item.getItemId()){

                            case (R.id.bluetoothOn):

                                final BluetoothAdapter bAdapter = BluetoothAdapter.getDefaultAdapter();

                                if(bAdapter == null)
                                {
                                    Toast.makeText(context,stToast13,Toast.LENGTH_SHORT).show();
                                }
                                else{
                                    if(!bAdapter.isEnabled()){
                                        try{
                                            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),1);
                                            Toast.makeText(context,bluetoothOn,Toast.LENGTH_SHORT).show();
                                        }catch(Exception e){
                                            errorMsg(e.toString());
                                        }

                                    }
                                }


                            case(R.id.emparejar):
                                Toast.makeText(context,"You Clicked : " + item.getTitle(),Toast.LENGTH_SHORT).show();
                            case (R.id.path):

                        }

                        return true;
                    }
                });

                popup.show();//showing popup menu
            }});



        lista = (ArrayList<DatosArduinoRString>) MainActivity.allData.FabricaResumen();


        AdaptadorResumen adaptador = new AdaptadorResumen(context, lista);


        ListaResumen.setAdapter(adaptador);



return root;

    }
    public static void toastsave(){
        ResumenFragment toast12 = new ResumenFragment();
        String text = toast12.getStToast12();
        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
    }
    public static void toastnotsave(){
        ResumenFragment toast11 = new ResumenFragment();
        String text = toast11.getStToast11();
        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
    }
    public static void toastread(){
        ResumenFragment toast14 = new ResumenFragment();
        String text = toast14.getStToast14();
        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
         }
    public static void toastnotread(){
        ResumenFragment toast15 = new ResumenFragment();
        String text = toast15.getStToast15();
        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
    }

    public static void errorMsg(String e){
        final AlertDialog.Builder alertDialogBuilder = new
                AlertDialog.Builder(context);

        alertDialogBuilder.setMessage("Error: "+ e)
                .setCancelable(false)
                .setPositiveButton("???", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {  dialog.dismiss();

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();
        ResumenFragment toast11 = new ResumenFragment();
        String text = toast11.getStToast11();
        Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
    }

    public int path(){

        LayoutInflater li = LayoutInflater.from(context);
        View promptsView = li.inflate(R.layout.pathtext, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


        String [] items = {publico,privado};

        DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
             switch (which) {
                 case 0:
                     path_opcion = 0;

                 case 1:
                     path_opcion = 1;

             }
            }
        };
        alertDialogBuilder.setTitle(pathTitle);
        alertDialogBuilder.setItems (items , listener);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        LayoutInflater li = LayoutInflater.from(context);
                        View promptsView = li.inflate(R.layout.pathtext, null);

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


                        alertDialogBuilder.setTitle(pathTitle);
                        switch (path_opcion){
                            case 0:
                        alertDialogBuilder.setMessage(pathTitle + " " + Data.dirpath );
                        break;
                            case 1:
                                alertDialogBuilder.setMessage(pathTitle+ " " + privado  );
                        };
                                alertDialogBuilder.setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {


                                        dialog.dismiss();


                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {


                                        dialog.cancel();


                                    }
                                });

                        AlertDialog alertDialog = alertDialogBuilder.create();

                        alertDialog.show();



                        dialog.dismiss();


                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {


                        dialog.cancel();


                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();
return path_opcion;
    };

}

