package com.sistemaderiegoandroid_arduino.ui.Resumen;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.provider.DocumentsContract;
import android.app.Activity;
import androidx.core.content.FileProvider;


import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.sistemaderiegoandroid_arduino.AdaptadorResumen;
import com.sistemaderiegoandroid_arduino.Data;
import com.sistemaderiegoandroid_arduino.DatosArduinoRString;
import com.sistemaderiegoandroid_arduino.MainActivity;
import com.sistemaderiegoandroid_arduino.R;

import java.io.File;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;
import static android.content.Intent.ACTION_CREATE_DOCUMENT;
import static android.os.Environment.*;

public class ResumenFragment extends Fragment {
    private EditText path;
    public static Context context;
    private int path_opcion;

    private static String stToast11;
    private static String stToast12;
    private static String stToast13;
    private static String stToast14;
    private static String stToast15;
    private static String pathTitle;
    private static String bluetoothOn;
    private Uri fileUri;
    public static int activadoT = 0;
    public static int activadoL = 0;
    public static int activadoH = 0;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.resumen, container, false);

        context = root.getContext();

        stToast11 = getString(R.string.stToast11);
        stToast12 = getString(R.string.stToast12);
        stToast13 = getString(R.string.stToast13);
        stToast14 = getString(R.string.stToast14);
        stToast15 = getString(R.string.stToast15);
        pathTitle = getString(R.string.PathTitle);
        bluetoothOn = getString(R.string.bluetoothOn);

        final TextView titulo =
                root.findViewById(R.id.titulo);
        final TextView resumen = root.findViewById(R.id.resumen);
        final Button archivo = (Button) root.findViewById(R.id.archivo);
        final Button arduino = (Button) root.findViewById(R.id.arduino);

        final ListView ListaResumen = root.findViewById(R.id.ListaResumen);

        archivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popup = new PopupMenu(context, archivo);
                popup.getMenuInflater().inflate(R.menu.popuparchivo, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()) {
                            case (R.id.save):
                                saveData(context);
                                break;
                            case (R.id.read):
                                //MainActivity.allData.loadData(context);
                                break;
                            case (R.id.path):
                                ResumenFragment path = new ResumenFragment();
                                path.path();
                                break;
                        }
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });


        arduino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popup = new PopupMenu(context, arduino);
                popup.getMenuInflater().inflate(R.menu.popuparduino, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    @Override

                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId()) {
                            case (R.id.bluetoothOn):
                                final BluetoothAdapter bAdapter = BluetoothAdapter.getDefaultAdapter();
                                if (bAdapter == null) {
                                    Toast.makeText(context, stToast13, Toast.LENGTH_SHORT).show();
                                } else {
                                    if (!bAdapter.isEnabled()) {
                                        try {
                                            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 1);
                                            Toast.makeText(context, bluetoothOn, Toast.LENGTH_SHORT).show();
                                        } catch (Exception e) {
                                            errorMsg(e.toString());
                                        }
                                    }
                                }
                            case (R.id.emparejar):
                                Toast.makeText(context, "You Clicked : " + item.getTitle(), Toast.LENGTH_SHORT).show();
                            case (R.id.path):
                        }
                        return true;
                    }
                });

                popup.show();//showing popup menu
            }
        });
        ArrayList<DatosArduinoRString> lista =
                new ArrayList<DatosArduinoRString>();
        lista = (ArrayList<DatosArduinoRString>) MainActivity.allData.FabricaResumen();
        AdaptadorResumen adaptador = new AdaptadorResumen(context, lista);
        ListaResumen.setAdapter(adaptador);
        return root;
    }

    public static void toastsave() {
        Toast.makeText(context, stToast12, Toast.LENGTH_SHORT).show();
    }

    public static void toastnotsave() {
        Toast.makeText(context, stToast11, Toast.LENGTH_SHORT).show();
    }

    public static void toastread() {
        Toast.makeText(context, stToast14, Toast.LENGTH_SHORT).show();
    }

    public static void toastnotread() {
        Toast.makeText(context, stToast15, Toast.LENGTH_SHORT).show();
    }

    public static void errorMsg(String e) {
        final AlertDialog.Builder alertDialogBuilder = new
                AlertDialog.Builder(context);

        alertDialogBuilder.setMessage("Error: " + e)
                .setCancelable(false)
                .setPositiveButton("???", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();
        Toast.makeText(context, stToast11, Toast.LENGTH_SHORT).show();
    }

    public int path() {

        LayoutInflater li = LayoutInflater.from(context);
        View promptsView = li.inflate(R.layout.pathtext, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


        alertDialogBuilder.setTitle(pathTitle);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        LayoutInflater li = LayoutInflater.from(context);
                        View promptsView = li.inflate(R.layout.pathtext, null);

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);


                        alertDialogBuilder.setTitle(pathTitle);

                        alertDialogBuilder.setMessage(pathTitle + " " + Data.dirpath);
                        alertDialogBuilder.setCancelable(false)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.dismiss();
                                    }
                                });

                        AlertDialog alertDialog = alertDialogBuilder.create();

                        alertDialog.show();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
        return path_opcion;

    }

    ;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void saveData(Context context) {
        activadoT = 0;
        activadoL = 0;
        activadoH = 0;

        if (MainActivity.allData.arrayDatosTiempo != null) {
            for (int i = 0; i < MainActivity.allData.arrayDatosTiempo.length; i++) {
                if (Data.arrayDatosTiempo[i].getActivado() == 1) {
                    activadoT = 1;
                }
            }
        }
        ;
        if (MainActivity.allData.arrayDatosHumedad != null) {
            for (int i = 0; i < MainActivity.allData.arrayDatosHumedad.length; i++) {
                if (Data.arrayDatosHumedad[i].getActivado() == 1) {
                    activadoH = 1;
                }
            }
            ;
        }
        ;
        if (MainActivity.allData.arrayDatosLuz != null) {
            for (int i = 0; i < MainActivity.allData.arrayDatosLuz.length; i++) {
                if (Data.arrayDatosLuz[i].getActivado() == 1) {
                    activadoL = 1;
                }
            }
            ;
        }
        ;
        String a = getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS).toString();
        File file = new File(a);

        if (activadoH == 1 | activadoL == 1 | activadoT == 1) {


            if (file != null) {
                try {

                    fileUri = Uri.fromFile(file);
                    context.grantUriPermission("com.sistemaderiegoandroid_arduino", fileUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                } catch (Exception e) {
                    ResumenFragment.errorMsg("e.toString()");
                }
                ;
            }
            ;

            try {
                if (!file.mkdirs()) {

                    file.mkdir();
                }
                ;
            } catch (Exception e) {
                ResumenFragment.errorMsg(e.toString());
            }
            ;

            File fileNameR = null;
            File fileNameT = null;
            File fileNameH = null;
            File fileNameL = null;

            try {

                fileNameR = new File(file, "arduino_data_resumen.bin");
                fileNameT = new File(file, "arduino_data_tiempo.bin");
                fileNameH = new File(file, "arduino_data_humedad.bin");
                fileNameL = new File(file, "arduino_data_luz.bin");
                //            private void createFile( Uri pickerInitialUri, File file_name) {

                createFile(fileUri, fileUri, fileNameR);
                createFile(fileUri, fileUri, fileNameT);
                createFile(fileUri, fileUri, fileNameH);
                createFile(fileUri, fileUri, fileNameL);


            } catch (Exception e) {
                ResumenFragment.errorMsg(e.toString());
            }
            ;

        }
        MainActivity.allData.saveData(context);
    }

    public static final int CREATE_FILE = 1;
    public static final int OPEN_FILE = 2;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createFile(Uri pickerInitialUri,Uri fileUri, File file_name) {


        Intent intent = new Intent(ACTION_CREATE_DOCUMENT);
        intent.setDataAndType(fileUri, "application/bin");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_TITLE, file_name);
        // Optionally, specify a URI for the directory that should be opened in
        // the system file picker when your app creates the document.
        intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri);

        startActivityForResult(intent, CREATE_FILE);
        onActivityResult(CREATE_FILE,RESULT_OK,intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {
        if (requestCode == CREATE_FILE
                && resultCode == RESULT_OK) {
            // The result data contains a URI for the document or directory that
            // the user selected.
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                // Perform operations on the document using its URI.
                final int takeFlags = resultData.getFlags()
                        & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
// Check for the freshest data.
                getActivity().getContentResolver().takePersistableUriPermission(uri, takeFlags);
            }
        }
    }

}