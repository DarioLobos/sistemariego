package com.sistemariego;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.sistemariego.R;

public class RiegoTiempo extends Activity {

//private boolean english;
//private TextView titulo;
//private TextView riegoT;

 @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.riegotiempo);
     

Bundle bdlenglish = getIntent().getExtras();

final int language = (int) bdlenglish.getInt("traducir");

final TextView titulo = findViewById(R.id.titulo);
final TextView riegoT = findViewById(R.id.riegoT);
String [] solenoide = new String []{"Programar solenoide 1","Programar solenoide 2","Programar solenoide 3",
"Programar solenoide 4", "Programar solenoide 5","Programar solenoide 6"};

switch (language) {
case 1: titulo.setText("Automatic Watering System");
riegoT.setText("by date and time");
solenoide[0]="Program solenoid 1";
solenoide[1]="Program solenoid 2";
solenoide[2]="Program solenoid 3";
solenoide[3]="Program solenoid 4";
solenoide[4]="Program solenoid 5";
solenoide[5]="Program solenoid 6";

};


ArrayAdapter<String> adapSolenoide = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1, solenoide);

ListView solenoides = (ListView) findViewById(R.id.solenoides);

solenoides.setAdapter(adapSolenoide);

solenoides.setOnItemClickListener(new AdapterView.OnItemClickListener()
{ 
@Override
public void onItemClick(AdapterView<?> a,View v, int position, long id) {

 Intent solfecha = new Intent(RiegoTiempo.this,SoleTiempo.class);
    Bundle tiempo = new Bundle();
 tiempo.putInt("traducir", language);
 tiempo.putInt("nrosolenoide",position);
   solfecha.putExtras(tiempo);
       
      startActivity(solfecha);};
 });
 
}
}
