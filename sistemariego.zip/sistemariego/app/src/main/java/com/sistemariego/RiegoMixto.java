package com.sistemariego;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.sistemariego.R;

public class RiegoMixto extends Activity {
private static int language;
private String stToast6;
private String stToast7;
private String stToast8;
private String stToast9;
private String stToast10;
private TableLayout riegomixto;
RadioGroup.OnCheckedChangeListener a1; 
RadioGroup.OnCheckedChangeListener a2; 
RadioGroup.OnCheckedChangeListener a3; 
//private boolean english;
//private TextView titulo;
//private TextView riegoT;

 @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.riegomixto);
     

Bundle bdlenglish = getIntent().getExtras();


language = (int) bdlenglish.getInt("traducir");

final Button actualizar =
findViewById(R.id.actualizar);
final Button backMain =
findViewById(R.id.backMain);

final TextView titulo =
 findViewById(R.id.titulo);
final TextView riegoM = 
findViewById(R.id.riegoM);
final TextView riegoLuz= findViewById(R.id.riegoM);
final TextView riegoTiempo= findViewById(R.id.riegoTiempo);
final TextView riegoHumedad= findViewById(R.id.riegoHumedad);
final CheckBox rb1 =
findViewById (R.id.rb1);
final CheckBox rb2 =
findViewById (R.id.rb2);
final CheckBox rb3 =
findViewById (R.id.rb3);
final TextView debeMixto =
findViewById (R.id.debeMixto);
final TextView debeAndOr =
findViewById (R.id.debeAndOr);
final RadioGroup groupAndOr3 =
findViewById (R.id.groupAndOr3);
final RadioButton rbAnd3 =
findViewById (R.id.rbAnd3);
final RadioButton rbOr3 =
findViewById (R.id.rbOr3);
final RadioGroup groupAndOr2 =
findViewById (R.id.groupAndOr2);
final RadioButton rbAnd2 =
findViewById (R.id.rbAnd2);
final RadioButton rbOr2 =
findViewById (R.id.rbOr2);
final RadioGroup groupAndOr1 =
findViewById (R.id.groupAndOr1);
final RadioButton rbAnd1 =
findViewById (R.id.rbAnd1);
final RadioButton rbOr1 =
findViewById (R.id.rbOr1);
riegomixto =
findViewById (R.id.riegomixto);
switch (language) {
case 1: titulo.setText("Automatic Watering System");
riegoM.setText("by mixing the three systems");
riegoTiempo.setText("by date and time");
riegoHumedad.setText("by soil humedity");
riegoLuz.setText("by day light (night-day)");
rb1.setText("Activated");
rb2.setText("Activated");
rb3.setText("Activated");
actualizar.setText("Update record");
backMain.setText("Main menu");
debeMixto.setText("BEFORE COMPLETE THIS FORM MUST UDATE THE RECORDS OF THE WATERING DESIRED");
debeAndOr.setText("THE CRITERIA AND/OR MUST BE THAT IF YOU WANT WATERING BY HUMIDITY IN THE SUNSET OR AT 6PM YOU MUST FILL AND HUMIDITY, AND DAY/NIGHT, OR DATE/TIME. One AND only is same as three OR.");
stToast6 = "Redord updated";
stToast7 = "All fields must be completed";
stToast8 = "Must program solenoids first";
stToast9 = "Solenoids activated";
stToast10 = "Solenoids deactivated";
default: 
stToast6 = "Registro actualizado";
stToast7 = "Todos los campos deben ser completados";
stToast8 = "Debe programar solenoides primero";
stToast9 = "Solenoides activados";
stToast10 = "Solenoides desactivados";
;
};

 a1 = new RadioGroup.OnCheckedChangeListener() {

 @Override
 public void onCheckedChanged(RadioGroup group, int checkedId) {
int d = MainActivity.allData.solenoidesRegistradosT();
if (d>0){

switch (checkedId){
case R.id.rbAnd1:
MainActivity.allData.setAndOrT(2);
Toast.makeText(getApplicationContext(),"AND",Toast.LENGTH_SHORT).show();
  break;
case R.id.rbOr1:
MainActivity.allData.setAndOrT(1);
Toast.makeText(getApplicationContext(),"OR",Toast.LENGTH_SHORT).show();
  break;
 default:
MainActivity.allData.setAndOrT(-1);
  break;
};

}else{ 


doClear(groupAndOr1,a1);

 

};

}
};
groupAndOr1.setOnCheckedChangeListener(a1);


a2 = new RadioGroup.OnCheckedChangeListener() {

 @Override
 public void onCheckedChanged(RadioGroup group, int checkedId) {
int d = MainActivity.allData.solenoidesRegistradosL();
if (d>0){

switch (checkedId){
case R.id.rbAnd2:
MainActivity.allData.setAndOrL(2);
Toast.makeText(getApplicationContext(),"AND",Toast.LENGTH_SHORT).show();
  break;
case R.id.rbOr2:
MainActivity.allData.setAndOrL(1);
Toast.makeText(getApplicationContext(),"OR",Toast.LENGTH_SHORT).show();
  break;
 default:
MainActivity.allData.setAndOrL(-1);
  break;
};

}else{ 


doClear(groupAndOr2,a2);

 

};

}
};
groupAndOr2.setOnCheckedChangeListener(a2);


a3 = new RadioGroup.OnCheckedChangeListener() {

 @Override
 public void onCheckedChanged(RadioGroup group, int checkedId) {
int d = MainActivity.allData.solenoidesRegistradosH();
if (d>0){

switch (checkedId){
case R.id.rbAnd3:
MainActivity.allData.setAndOrH(2);
Toast.makeText(getApplicationContext(),"AND",Toast.LENGTH_SHORT).show();
  break;
case R.id.rbOr3:
MainActivity.allData.setAndOrH(1);
Toast.makeText(getApplicationContext(),"OR",Toast.LENGTH_SHORT).show();
  break;
 default:
MainActivity.allData.setAndOrH(-1);
  break;
};

}else{ 


doClear(groupAndOr3,a3);

 

};

};
};
groupAndOr3.setOnCheckedChangeListener(a3);

rb1.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
 @Override
  public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
  if (isChecked){
 
  int d = MainActivity.allData.solenoidesRegistradosT();
  if (d>0){
    
    MainActivity.allData.activaSolenoideT(1);
    Toast.makeText(getApplicationContext(),stToast9,Toast.LENGTH_SHORT).show();
    
    }
  else{
   rb1.setChecked(false); Toast.makeText(getApplicationContext(),stToast8,Toast.LENGTH_SHORT).show();
 };
 }
  else{
     
        MainActivity.allData.activaSolenoideT(-1);
      Toast.makeText(getApplicationContext(),stToast10,Toast.LENGTH_SHORT).show();
    
  }
  
  }
  });
  
  rb2.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
 @Override
  public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
  if (isChecked){
 
  int d = MainActivity.allData.solenoidesRegistradosL();
  if (d>0){
    
    MainActivity.allData.activaSolenoideL(1);
    Toast.makeText(getApplicationContext(),stToast9,Toast.LENGTH_SHORT).show();
    
    }
  else{
   rb2.setChecked(false); Toast.makeText(getApplicationContext(),stToast8,Toast.LENGTH_SHORT).show();
 };
 }
  else{
     
        MainActivity.allData.activaSolenoideL(-1);
      Toast.makeText(getApplicationContext(),stToast10,Toast.LENGTH_SHORT).show();
    
  }
  
  }
  });
  
  rb3.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
 @Override
  public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
  if (isChecked){
 
  int d = MainActivity.allData.solenoidesRegistradosH();
  if (d>0){
    
    MainActivity.allData.activaSolenoideH(1);
    Toast.makeText(getApplicationContext(),stToast9,Toast.LENGTH_SHORT).show();
    
    }
  else{
   rb3.setChecked(false); Toast.makeText(getApplicationContext(),stToast8,Toast.LENGTH_SHORT).show();
 };
 }
  else{
     
        MainActivity.allData.activaSolenoideH(-1);
      Toast.makeText(getApplicationContext(),stToast10,Toast.LENGTH_SHORT).show();
    
  }
  
  }
  });
  
  
};

public void clickBackMain(View view){
  MainActivity.memory_lang=language;
     Intent soleMixto = new Intent(RiegoMixto.this,MainActivity.class);
startActivity(soleMixto);

};
  
public void botonActualizar(View view){


Toast.makeText(getApplicationContext(),stToast6,Toast.LENGTH_SHORT).show();




};
public void doClear(final RadioGroup g,
RadioGroup.OnCheckedChangeListener a
 ){

Toast.makeText(getApplicationContext(),stToast8,Toast.LENGTH_SHORT).show();
g.setOnCheckedChangeListener(null);
                 g.clearCheck();
 g.setOnCheckedChangeListener(a);

};
}

