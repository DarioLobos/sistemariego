package com.sistemariego;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.MainThread;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.sistemariego.DatosArduino;
import com.sistemariego.DatosArduinoH;
import com.sistemariego.MainActivity;
import com.sistemariego.R;
import java.lang.Math;
import java.lang.StringBuilder;
import java.util.Calendar;

public class SoleHumedad extends Activity{
private static int language;
private int nroSolenoide;
private DatePicker datepicker;
private Calendar calendar;
private static  int year, month ,day,hora,minuto;
private static int fechaInicio;
private static int humedad;
private TextView txtHumedad;
private static int tiempoRiego1;
private static int fechaFin;
private TextView txtfechaInicio;
private TextView txtfechaFin;
private TextView txtTiempo1;
private String stToast;
private String stToast2;
private String stToast3;
private String stToast4;
private String stToast5;
private String stToast6;
private String stToast7;
private Button boton;
private Button tiempo1;
private static int datatoiniciofin= 0;
private static int datatoiniciofint= 0;
private String txtnoDate="";
private static int returnFecha;
private Button pkHumedad;
private NumberPicker numberpicker;
private String txtdialogDate;
private String txtdialogHumedad;
private String txtdialogTimer;
public static String txtdias;
public static String [] arrayDias = new String[8];
private Context context = this;

public static int diasSelected=0;

public static int setDias=0;

private static boolean [] arrayCkDias = {false,false,false,false,false,false,false,false};
AlertDialog alertDialog;
static String txtDiasSelected;
static String txtDiasSel;
TextView diasTexto;
Button backMain;
 @Override
    protected void onCreate(Bundle savedInstanceState) 
{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datos_humedad);
     

Bundle bundleHumedad= getIntent().getExtras();
language = (int) bundleHumedad.getInt("traducir");
nroSolenoide = (int) bundleHumedad.getInt("nrosolenoide");
final TextView titulo = (TextView) findViewById(R.id.titulo);
final TextView riegoH = (TextView) findViewById(R.id.riegoH);
final TextView soleNro = (TextView)
findViewById(R.id.soleNro);
final TextView textFechaInicio = (TextView)
findViewById(R.id.fechaInicio);
final TextView textfechaFin = (TextView) findViewById(R.id.fechaFin);
final Button dPickInicio = findViewById(R.id.dPickInicio);
final Button dPickFin = findViewById(R.id.dPickFin);
final TextView xmlHumedad =
(TextView) findViewById(R.id.xmlHumedad);
txtHumedad =
(TextView) findViewById(R.id.txtHumedad);
final Button pkHumedad = findViewById(R.id.pkHumedad);
 final CheckBox noDate = (CheckBox) findViewById(R.id.noDate);
 txtfechaInicio = (TextView) findViewById(R.id.dateInicio);
txtfechaFin = (TextView) findViewById(R.id.dateFin);
tiempo1 = 
findViewById(R.id.tiempo1);
txtTiempo1 = (TextView)
findViewById(R.id.txtTiempo1);
diasTexto= (TextView) findViewById(R.id.diasTexto);
Button actualizar= (Button) findViewById(R.id.actualizar);
Button dias2 = findViewById(R.id.dias);
backMain = findViewById(R.id.backMain);

switch (language) {
case 1:
titulo.setText("Automatic Watering System");
riegoH.setText("by soil humidity");
soleNro.setText("PROGRAMMING SOLENOID NUMBER " + (nroSolenoide + 1));
stToast = "Opening date Picker";
stToast2 = "Opening humedity Picker";
stToast3 = "Opening watering timer";
stToast4 = "DATA ERROR INPUT";
stToast5 = "DATA CHARGED";
stToast6 = "Redord updated";
stToast7 = "All fields must be completed";
textFechaInicio.setText("Starting Date");
textfechaFin.setText("Ending Date");
dPickInicio.setText("Update");
dPickFin.setText("Update");
txtnoDate="No date selected";
noDate.setText("Without Date");
xmlHumedad.setText("Humedity for watering (%)");
pkHumedad.setText("Humidity(%)");
tiempo1.setText("Timer");
txtdialogDate="Dates of watering";
txtdialogHumedad="Humedity for watering";
txtdialogTimer="Minutes of watering";
txtdias="Days to watering";
actualizar.setText("Update record");
arrayDias[0]="Every day";
arrayDias[1]="Monday";
arrayDias[2]="Tuesday";
arrayDias[3]="Wedneaday";
arrayDias[4]="Thursday";
arrayDias[5]="Friday";
arrayDias[6]="Saturday";
arrayDias[7]="Sunday";
txtDiasSel="Selected days: ";
dias2.setText("Days");
backMain.setText("Main menu");
break;
default:
soleNro.setText("PROGRANDO NUMERO DE SOLENIDE " + (nroSolenoide + 1));
stToast = "Abriendo selector fecha";
stToast2 = "Abriendo selector humedad";
stToast3 = "Abriendo temporizador de riego";
stToast4 = "DATO INGRESADO ERRADO";
stToast5 = "DATO CARGADO";
stToast6 = "Registro actualizado";
stToast7 = "Todos los campos deben ser completados";
txtnoDate = "Seleccionado sin fecha";
txtdialogDate="Fechas de riego";
txtdialogHumedad="Humedad para regar (%)";
txtdialogTimer="Minutos de riego";
txtdias="Dias de riego";
arrayDias[0]="Todos los dias";
arrayDias[1]="Lunes";
arrayDias[2]="Martes";
arrayDias[3]="Miercoles";
arrayDias[4]="Jueves";
arrayDias[5]="Viernes";
arrayDias[6]="Sabado";
arrayDias[7]="Domingo";
txtDiasSel="Dias selecionados: ";

break;

 };
if (MainActivity.allData.getFechaInicioDataH(nroSolenoide)>0){
  makeintdate(txtfechaInicio, MainActivity.allData.getFechaInicioDataH(nroSolenoide));

makeintdate(txtfechaFin, MainActivity.allData.arrayDatosHumedad[nroSolenoide].fechafin);


maketimertext1(MainActivity.allData.arrayDatosHumedad[nroSolenoide].tiemporiego1);
makeHumedadText(MainActivity.allData.arrayDatosHumedad[nroSolenoide].humedad);
  
  diasTexto.setText(txtDiasSel + diasSeleccionados(MainActivity.allData.arrayDatosHumedad[nroSolenoide].diasSemana));
  
};


noDate.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
 @Override
  public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
    
    if (isChecked){
 fechaInicio=99999999;
fechaFin=99999999;
txtfechaInicio.setText(txtnoDate);
txtfechaFin.setText(txtnoDate);
};
};
});



calendar = Calendar.getInstance();
year = (int) calendar.get(Calendar.YEAR);
month = (int) calendar.get(Calendar.MONTH);
day = (int) calendar.get(Calendar.DAY_OF_MONTH);

        dias2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               
          
          
  final AlertDialog.Builder alertDialogBuilder = new 
   AlertDialog.Builder(context);
alertDialogBuilder.setView(android.R.layout.simple_selectable_list_item);


alertDialogBuilder.setMultiChoiceItems(arrayDias,arrayCkDias, new DialogInterface.OnMultiChoiceClickListener() {
    @Override
    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
 
      final AbsListView listDias =  (AbsListView) alertDialog.getListView();
       
  
        if (((diasSelected/128)==1) & (which>0) & (!(isChecked))){
       setDias=128;
         diasSelected =
        diasSelected  & (~setDias);
        arrayCkDias[0]=false;
        
         listDias.setItemChecked(0,false);
        };
        
        
        
        switch (which){
        case 0:
        if(isChecked){
        
        for(int i=1; i < 8; i++){
    listDias.setItemChecked(i,true);  
        arrayCkDias[i]=true;};
       
       
        diasSelected = 255;
        
        };
        break;
        case 1:
        setDias=1;
        if(isChecked){
        diasSelected= diasSelected | setDias;
        
        }
        else
        {
        diasSelected =
        diasSelected  & (~setDias);
        
        };
        break;
        case 2:
        setDias=2;
        if(isChecked) {
        diasSelected= diasSelected | setDias;
        
        }
        else
        {diasSelected =
        diasSelected  & (~setDias);
        };
        break;
        case 3:
        setDias=4;
        if(isChecked){
        diasSelected= 
        diasSelected | setDias;
        
        }
        else{
        diasSelected =
        diasSelected  & (~setDias);
        };
        break;
        case 4:
        setDias=8;
        if(isChecked){
       diasSelected= 
        diasSelected | setDias;
        
        }
        else{
        diasSelected =
        diasSelected  & (~setDias);
        
        };
        break;
        case 5:
        setDias=16;
        if(isChecked){
        diasSelected = 
        diasSelected | setDias;
        
        }
        else
        {diasSelected =
        diasSelected  & (~setDias);
        };
        break;
        case 6:
        setDias=32;
        if(isChecked){
        diasSelected= diasSelected | setDias;
        
        }
        else{diasSelected =
        diasSelected  & (~setDias);
        };
        break;
        case 7:
        
        setDias=64;
        if(isChecked){
        diasSelected= diasSelected | setDias;
        
        }
        else{
        diasSelected =
        diasSelected  & (~setDias);
        };
        break;
        };
}
});
  


alertDialogBuilder.setPositiveButton("Ok",new DialogInterface.OnClickListener() {
public void onClick(DialogInterface dialog,int id) {
// if this button is clicked, close
// current activityi
diasTexto.setText(txtDiasSel + diasSeleccionados(diasSelected));
alertDialog.dismiss();
}
 });
 alertDialogBuilder.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
public void onClick(DialogInterface dialog,int id) {

 final AbsListView listDias =  (AbsListView) alertDialog.getListView();
diasTexto.setText(" ");
for(int i=0; i < 8; i++){
listDias.setItemChecked(i,false);
       arrayCkDias[i]=false;};
diasSelected=0;
alertDialog.dismiss();

}
});



// create alert dialog
alertDialog = alertDialogBuilder.create();
// show it
alertDialog.show();
}
});

};
  
public String diasSeleccionados(int diasSelected) {
  if ((diasSelected/128)==1){
    txtDiasSelected= arrayDias[0];
  }
  else{
    StringBuilder builDias =
     new StringBuilder();
     for (int i = 0; i < 7; i++){
      int diasselector=diasSelected & (int)(Math.pow((double)2,(double)i));
      int bitOn = diasselector >> i;
       if (bitOn==1){ builDias.append(arrayDias[i+1]).append("  ");
       };
     };
     
  txtDiasSelected = builDias.toString(); 
   
     };
     return txtDiasSelected;
  };
public void clickBackMain(View view){
  MainActivity.memory_lang=language;
     Intent soleHumedad = new Intent(SoleHumedad.this,MainActivity.class);
startActivity(soleHumedad);
};
  
public void botonActualizar(View view){

final int activado = 1;
final int andOr=-1; 
//public DatosArduinoH(int activado, int andOr, int fechainicio,int fechafin,int  tiemporiego1,int diasSemana,int humedad))
if ((fechaInicio>0)&(fechaFin>0)&(tiempoRiego1>0)&(diasSelected>0)&(humedad>0)){
DatosArduinoH data = new DatosArduinoH(activado,andOr,fechaInicio , fechaFin, tiempoRiego1,diasSelected,humedad);
MainActivity.allData.programaSolenoideH(data, nroSolenoide);
Toast.makeText(getApplicationContext(),stToast6,Toast.LENGTH_SHORT).show();}
else{
  Toast.makeText(getApplicationContext(),stToast7,Toast.LENGTH_SHORT).show();
};

};

 @SuppressWarnings("deprecation")
  
public void botonClickInicio(View view)
{
final CheckBox noDate = (CheckBox) findViewById(R.id.noDate);
 boolean noDateck= noDate.isChecked();

if (noDateck){fechaInicio=99999999;
fechaFin=99999999;
txtfechaInicio.setText(txtnoDate);
txtfechaFin.setText(txtnoDate);}
else{
showDialog(999);
Toast.makeText(getApplicationContext(),stToast,Toast.LENGTH_SHORT).show();
datatoiniciofin =1;
};

}
  
public void botonClickFin(View view)
{
final CheckBox noDate = (CheckBox) findViewById(R.id.noDate);
 boolean noDateck= noDate.isChecked();
if (!(noDateck)){
showDialog(999);
Toast.makeText(getApplicationContext(),stToast,Toast.LENGTH_SHORT).show();
datatoiniciofin=2;}

else{fechaInicio=99999999;
fechaFin=99999999;
txtfechaInicio.setText(txtnoDate);
txtfechaFin.setText(txtnoDate);
};

}
     
//public void listener()


@Override
protected Dialog onCreateDialog(int id) 
{
    switch (id){
    
     case 999: 
       
     DatePickerDialog d = new DatePickerDialog(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK, myDateListener, year, month, day);
     d.setTitle(txtdialogDate);
             return d;
     
      
      default: return null;
      
                }
};
  
private DatePickerDialog.OnDateSetListener myDateListener = new 
      DatePickerDialog.OnDateSetListener() 
{
      @Override
      public void onDateSet(DatePicker arg0, 
         int arg1, int arg2, int arg3) {
         // TODO Auto-generated method stub
         // arg1 = year
         // arg2 = month
         // arg3 = day
 int dateNow = (year*10000)+((month+1)*100)+day;
  
 int dateSelec = (arg1*10000)+((arg2+1)*100)+arg3;
 
   if (dateSelec > dateNow) {
  
  returnFecha= dateSelec;
      }
  else {
    returnFecha = dateNow;
    Toast.makeText(getApplicationContext(),stToast4,Toast.LENGTH_SHORT).show();
       };
       
       switch (datatoiniciofin){
         case 1:
         if(fechaFin<returnFecha){
         fechaFin=returnFecha;
         fechaInicio=returnFecha;
         Toast.makeText(getApplicationContext(),stToast4,Toast.LENGTH_SHORT).show();
         }
         else{
       fechaInicio=returnFecha;
       Toast.makeText(getApplicationContext(),stToast5,Toast.LENGTH_SHORT).show();
       }       
         break;
         
         
         case 2:
         if(fechaInicio<returnFecha){
         fechaFin=returnFecha; 
  Toast.makeText(getApplicationContext(),stToast5,Toast.LENGTH_SHORT).show();
         }
         else {fechaFin=fechaInicio; 
         Toast.makeText(getApplicationContext(),stToast4,Toast.LENGTH_SHORT).show();
         }
         break;
       };
makeintdate(txtfechaInicio, fechaInicio);
makeintdate(txtfechaFin,fechaFin);
};
};

  
public void makeintdate(TextView v,int a){
if (a>0){
int y = a/10000;
int m = (a-(y*10000))/100;
int d = (a-(y*10000+m*100));
StringBuilder b = new StringBuilder().
append(y).
append("/").
append(m).
append("/").
append(d);
v.setText(b);
};


};

  
public void botonHumedad(View view)
{
Toast.makeText(getApplicationContext(),stToast2,Toast.LENGTH_SHORT).show();

Context context = this;
final Dialog dialog = new Dialog(context);

dialog.setContentView(R.layout.timer);

dialog.setTitle(txtdialogHumedad);

final NumberPicker numberpicker = (NumberPicker) dialog.findViewById(R.id.numberpicker);

numberpicker.setWrapSelectorWheel(true);
numberpicker.setMinValue(10);
numberpicker.setMaxValue(90);
 
final Button ok1 = (Button) dialog.findViewById(R.id.ok1);

ok1.setOnClickListener( new OnClickListener(){
@Override
public void onClick(View view){
if (numberpicker.getValue()>0){
humedad = numberpicker.getValue();
makeHumedadText(humedad);
Toast.makeText(getApplicationContext(),stToast5,Toast.LENGTH_SHORT).show();
dialog.dismiss();};
}
});

final Button cancel1 = (Button) dialog.findViewById(R.id.cancel1);

cancel1.setOnClickListener( new OnClickListener(){
@Override
public void onClick(View view){
dialog.cancel();
}
});

dialog.show();

};
public void makeHumedadText(int t){

StringBuilder txt = new  StringBuilder().append(t).append(" %");
txtHumedad.setText(txt);
};

  
public void botonTiempoRiego1(View view)
{
Toast.makeText(getApplicationContext(),stToast3,Toast.LENGTH_SHORT).show();

Context context = this;
final Dialog dialog = new Dialog(context);

dialog.setContentView(R.layout.timer);

dialog.setTitle(txtdialogTimer);

final NumberPicker numberpicker = (NumberPicker) dialog.findViewById(R.id.numberpicker);

numberpicker.setWrapSelectorWheel(true);
numberpicker.setMinValue(1);
numberpicker.setMaxValue(180);
 
final Button ok1 = (Button) dialog.findViewById(R.id.ok1);

ok1.setOnClickListener( new OnClickListener(){
@Override
public void onClick(View view){
if (numberpicker.getValue()>0){
  
tiempoRiego1 = numberpicker.getValue();
maketimertext1(tiempoRiego1);

Toast.makeText(getApplicationContext(),stToast5,Toast.LENGTH_SHORT).show();
maketimertext1(tiempoRiego1);
dialog.dismiss();};
}
});

final Button cancel1 = (Button) dialog.findViewById(R.id.cancel1);

cancel1.setOnClickListener( new OnClickListener(){
@Override
public void onClick(View view){
dialog.cancel();
}
});

dialog.show();

};

public void maketimertext1(int t){

StringBuilder txt = new  StringBuilder().append(t).append(" Min.");
txtTiempo1.setText(txt);
};
  

}