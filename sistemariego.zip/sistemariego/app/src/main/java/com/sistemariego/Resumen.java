package com.sistemariego;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View;
import android.view.ViewGroup;
import android.view.autofill.AutofillValue;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import com.sistemariego.AdaptadorResumen;
import com.sistemariego.R;
import java.io.*;
import java.util.*;
import java.util.ArrayList;

import android.bluetooth.BluetoothAdapter;

public class Resumen extends Activity {
private static int language;
static int languageAdap;
private static EditText path;
static Context context;
static View promptsView;
Button backMain;
private static String stToast11;
private static String stToast12;
private static String stToast13;
private static String pathTitle;
static String filePath="";
//MenuItem item;
//private boolean english;
//private TextView titulo;
//private TextView resumen;

ArrayList<DatosArduinoRString> lista =
new ArrayList<DatosArduinoRString>();


 @Override
    protected void onCreate(Bundle savedInstanceState) {
    
Bundle bdlenglish = getIntent().getExtras();

language = (int) bdlenglish.getInt("traducir");
 
languageAdap = language;

        super.onCreate(savedInstanceState);

setContentView(R.layout.resumen);
 
context = this;     
final TextView titulo = 
findViewById(R.id.titulo);
final TextView resumen = findViewById(R.id.resumen);
final Button archivo = (Button) findViewById(R.id.archivo);
final Button arduino = (Button) findViewById(R.id.arduino);
backMain = findViewById(R.id.backMain);



switch (language) {
case 1:
pathTitle="Access path:";
titulo.setText("Automatic Watering System");
 resumen.setText("Solenoids programing resume");
 backMain.setText("Main menu");
archivo.setText("File"); 
stToast11 = "The data had not been saved.";
stToast12 = "The data had been saved.";
stToast13 = "Bluetooth not supported";
default:
pathTitle="Ruta de acceso:";
stToast11 = "Los datos no han sido grabados.";
stToast12 = "Los datos han sido grabados.";
};
stToast13 = "Bluethooth no soportado";
final ListView ListaResumen = findViewById(R.id.ListaResumen);



archivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

PopupMenu popup = new PopupMenu(Resumen.this,archivo);               
          
if (language==1){  popup.getMenuInflater().inflate(R.menu.popuparchivoe, popup.getMenu());}

else{popup.getMenuInflater().inflate(R.menu.popuparchivo, popup.getMenu());
  
}
            
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
 @Override
  public boolean onMenuItemClick(MenuItem item) {
           
  switch(item.getItemId()){
  
  case (R.id.save):
  MainActivity.allData.saveData(Resumen.this,context,1);
  
  break;
  case(R.id.read):
  Toast.makeText(Resumen.this,"You Clicked read ",Toast.LENGTH_SHORT).show();
  break;
  case (R.id.path):
  filePath= path();
  break;
}
                        return true;
                    }
                });

                popup.show();//showing popup menu
}});
                

arduino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

PopupMenu popup = new PopupMenu(Resumen.this, arduino);


               
                if (language==1){  popup.getMenuInflater().inflate(R.menu.popuparduinoe, popup.getMenu());}
else{popup.getMenuInflater().inflate(R.menu.popuparduino, popup.getMenu());
  
}
               
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
 
 @Override          
 
public boolean onMenuItemClick(MenuItem item) {

switch(item.getItemId()){
  
  case (R.id.bluetoothOn):
  
  final BluetoothAdapter bAdapter = BluetoothAdapter.getDefaultAdapter();
        
      if(bAdapter == null)
                {
                    Toast.makeText(getApplicationContext(),stToast13,Toast.LENGTH_SHORT).show();
                }
                else{
                    if(!bAdapter.isEnabled()){
try{
                        startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),1);
                        Toast.makeText(getApplicationContext(),"Bluetooth ON",Toast.LENGTH_SHORT).show();
                    }catch(Exception e){
                      errorMsg(e.toString());
                    }
                    
                }
            }
  
  
  case(R.id.emparejar):
  Toast.makeText(Resumen.this,"You Clicked : " + item.getTitle(),Toast.LENGTH_SHORT).show();
  case (R.id.path):
  Toast.makeText(Resumen.this,pathTitle + filePath,Toast.LENGTH_SHORT).show();
}
                        
                        return true;
                    }
                });

                popup.show();//showing popup menu
         }});      



lista = (ArrayList<DatosArduinoRString>) MainActivity.allData.FabricaResumen();

AdaptadorResumen adaptador = new AdaptadorResumen(Resumen.this, lista);

 
ListaResumen.setAdapter(adaptador);



 
                
}
public static final void toastsave(){
  Toast.makeText(context,stToast12,Toast.LENGTH_SHORT).show();
}

public static final void errorMsg(String e){
  final AlertDialog.Builder alertDialogBuilder = new 
   AlertDialog.Builder(context);

alertDialogBuilder.setMessage("Error: "+ e)  
                        .setCancelable(false)  
                        .setPositiveButton("???", new DialogInterface.OnClickListener() {  
                            public void onClick(DialogInterface dialog, int id) {  dialog.dismiss();  
                                
                           }  
                        }); 
 
  	AlertDialog alertDialog = alertDialogBuilder.create();

				alertDialog.show();                                 
      Toast.makeText(context,stToast11,Toast.LENGTH_SHORT).show();                        
}

public void clickBackMain(View view){
  MainActivity.memory_lang=language;
     Intent resumen = new Intent(Resumen.this,MainActivity.class);
startActivity(resumen);
};

public String path(){
final String userPath=context.getDataDir().toString();
String returnPath="";
	LayoutInflater li = LayoutInflater.from(context);
View promptsView = li.inflate(R.layout.pathtext, null);

				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);

				alertDialogBuilder.setView(promptsView);

final EditText path = (EditText) promptsView.findViewById(R.id.path);
//path.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_YES);
//path.setAutofillHints("userPath");
//path.setAutofillHints(View.AUTOFILL_TYPE_TEXT);
//Autofill.forText(userPath);

alertDialogBuilder.setTitle(pathTitle)  
              .setCancelable(false)  
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {  
                            public void onClick(DialogInterface dialog, int id) {  


final String returnPath= path.getText().toString();
final String userPath=System.getProperty("user.dir");
  Toast.makeText(Resumen.this,pathTitle + userPath + filePath + returnPath,Toast.LENGTH_SHORT).show();
                                dialog.dismiss();  
                                
    
                           }  
                        })
  .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {  
                            public void onClick(DialogInterface dialog, int id) {  


final String returnPath="";
                                dialog.cancel();  
                                
    
                           }  
                        }); 
 
				AlertDialog alertDialog = alertDialogBuilder.create();

				alertDialog.show();                                                
				return returnPath;
}

}
