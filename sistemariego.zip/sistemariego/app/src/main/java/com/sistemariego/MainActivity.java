package com.sistemariego;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.sistemariego.Data;
import com.sistemariego.R;

public class MainActivity extends Activity {


//private RadioGroup menuppal;
//private RadioButton opcionT;
//private RadioButton opcionH;
//private RadioButton opcionL;
//private RadioButton opcionM;
//private RadioButton opcionCkd;
//private RadioButton opcionArduino;
//private Button ir;
//private CheckBox english;
//private CheckBox english2;
//private TextView titulo;

public static Data allData = new Data();
private int language;
public  static int memory_lang;


 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

final TextView titulo = (TextView) findViewById(R.id.titulo);
final RadioButton opcionT = (RadioButton) findViewById(R.id.rb1);
final RadioButton opcionL = (RadioButton) findViewById(R.id.rb2);
final RadioButton opcionH = (RadioButton) findViewById(R.id.rb3);
final RadioButton opcionM = (RadioButton) findViewById(R.id.rb4);
final RadioButton opcionC = (RadioButton) findViewById(R.id.rb5);
final RadioButton opcionR = (RadioButton) findViewById(R.id.rb6);

final Button ir= (Button) findViewById(R.id.btnIr);

final RadioGroup menuppal = (RadioGroup) findViewById(R.id.menuppal);

final CheckBox english2 = (CheckBox) findViewById(R.id.english); 

if(memory_lang==1){
english2.setChecked(true);
titulo.setText("Automatic Watering System");
opcionT.setText("by date and time");
opcionH.setText("by soil humedity");
opcionL.setText("by day light (night-day)");
opcionM.setText("by combining the three systems");
ir.setText("GO");
opcionC.setText("Arduino configuration");
opcionR.setText("Solenoids programming resume");
    };




//menuppal.clearCkeck();
menuppal.check(opcionT.getId());

ir.setOnClickListener(new View.OnClickListener() { 

  @Override
   public void onClick(View arg0){
   
    int clicked = menuppal.getCheckedRadioButtonId();
    
if (clicked == opcionT.getId()) {

      Intent riegoT = new Intent(MainActivity.this , RiegoTiempo.class);


if (english2.isChecked()){
  language =1;
} 
else {language =-1;};   
Bundle bdlenglish = new Bundle();
 bdlenglish.putInt("traducir", language);
riegoT.putExtras(bdlenglish);
      
           startActivity(riegoT);}
           
else if (clicked == opcionH.getId()){
       Intent riegoH = new Intent(MainActivity.this , RiegoHumedad.class);

if (english2.isChecked()){
  language =1;
} 
else {language =-1;};   

Bundle bdlenglish = new Bundle();

 bdlenglish.putInt("traducir", language);
   riegoH.putExtras(bdlenglish);    
      startActivity(riegoH);} 
            
else if (clicked == opcionL.getId()){
 
  Intent riegoL = new Intent(MainActivity.this , RiegoLuz.class);

if (english2.isChecked()){
  language =1;
} 
else {language =-1;};   

Bundle bdlenglish = new Bundle();

bdlenglish.putInt("traducir", language);
 
riegoL.putExtras(bdlenglish);
      startActivity(riegoL);}
            
else if (clicked == opcionM.getId()){
 
  Intent riegoM = new Intent(MainActivity.this , RiegoMixto.class);
  
if (english2.isChecked()){
  language =1;
} 
else {language =-1;};   

Bundle bdlenglish = new Bundle();

 bdlenglish.putInt("traducir", language);
 
riegoM.putExtras(bdlenglish);
      startActivity(riegoM);} 
      
else if (clicked == opcionC.getId()){
 
  Intent arduino = new Intent(MainActivity.this , Arduino.class);
  
  if (english2.isChecked()){
  language =1;
} 
else {language =-1;};  

Bundle bdlenglish = new Bundle();

 bdlenglish.putInt("traducir", language);
 
arduino.putExtras(bdlenglish);
      startActivity(arduino);} 
          
else if (clicked == opcionR.getId()){
 
  Intent resumen = new Intent(MainActivity.this , Resumen.class);
 
  if (english2.isChecked()){
  language =1;
} 
else {language =-1;};   

Bundle bdlenglish = new Bundle();

 bdlenglish.putInt("traducir", language);
 
resumen.putExtras(bdlenglish);
      startActivity(resumen);} 
else {
  Intent riegoT = new Intent(MainActivity.this , RiegoTiempo.class);

if (english2.isChecked()){
  language =1;
} 
else {language =-1;};   

Bundle bdlenglish = new Bundle();

 bdlenglish.putInt("traducir", language);
 
riegoT.putExtras(bdlenglish);
      startActivity(riegoT);}
 
  
};
 
});


english2.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){
 @Override
  public void onCheckedChanged(CompoundButton buttonView,boolean isChecked){
    
    if  (isChecked){
    titulo.setText("Automatic Watering System");
    opcionT.setText("by date and time");
    opcionH.setText("by soil humedity");
    opcionL.setText("by day light (night-day)");
    opcionM.setText("by combining the three systems");
    ir.setText("GO");
   opcionC.setText("Arduino configuration");
   opcionR.setText("Solenoids programming resume");
    }
    else { 
    titulo.setText("Sistema automatizado de riego");
    opcionT.setText("Por Fecha y Hora");
    opcionH.setText("Por humedad del suelo");
    opcionL.setText("Por Luz (dia/noche)");
    opcionM.setText("Convinando los tres sistemas");
    ir.setText("IR");
opcionC.setText("Configuracion Arduino");
 opcionR.setText("Resumen programacion solenoides");   
    }
  }
  
});


}
public static void main(String[] args){


}
}

