package com.sistemariego;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.sistemariego.AdaptadorResumen;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import android.view.LayoutInflater;

public class AdaptadorResumen extends ArrayAdapter<DatosArduinoRString> {


public AdaptadorResumen(Context context, ArrayList<DatosArduinoRString> data){

 super (context,0,data);};
 
@Override
public View getView(int position, View convertView, ViewGroup parent) {

DatosArduinoRString data= getItem(position);

if (convertView==null){
  convertView = LayoutInflater.from(getContext()).inflate(R.layout.arrayadapter, parent, false);
       }
if (Resumen.languageAdap==1){       
TextView activado = (TextView) convertView.findViewById(R.id.activado);
activado.setText("Activated:");
TextView andOr = (TextView) convertView.findViewById(R.id.andOr);
andOr.setText(" And / Or");
TextView fechaInicio= (TextView) convertView.findViewById(R.id.fechaInicio);
fechaInicio.setText("Starting Date:");
TextView fechafin= (TextView) convertView.findViewById(R.id.fechafin);
fechafin.setText("Ending Date:");
TextView tiemporiego1= (TextView) convertView.findViewById(R.id.tiemporiego1);
tiemporiego1.setText("Water timer 1 :");
TextView diasSemana= (TextView) convertView.findViewById(R.id.diasSemana);
diasSemana.setText("Day of week;");
TextView horainicio1= (TextView) convertView.findViewById(R.id.horainicio1);
horainicio1.setText("Starting time 1:");
TextView horainicio2= (TextView) convertView.findViewById(R.id.horainicio2);
horainicio2.setText("Starting time 2:");
TextView tiemporiego2= (TextView) convertView.findViewById(R.id.tiemporiego2);
tiemporiego2.setText("Water timer 2:");
TextView humedad= (TextView) convertView.findViewById(R.id.humedad);
humedad.setText("Humidity :");
TextView sensibilidadLuz= (TextView) convertView.findViewById(R.id.sensibilidadLuz);
sensibilidadLuz.setText("light %:");
TextView nocheDia= (TextView) convertView.findViewById(R.id.nocheDia);
nocheDia.setText("day / night");
TextView nroSolenoide= (TextView) convertView.findViewById(R.id.nroSolenoide);
nroSolenoide.setText("Sol. number:");
};

TextView a_activado = (TextView) convertView.findViewById(R.id.a_activado);
a_activado.setText(data.activado);
TextView a_andOr = (TextView) convertView.findViewById(R.id.a_andOr);
a_andOr.setText(data.andOr);
TextView a_fechaInicio= (TextView) convertView.findViewById(R.id.a_fechaInicio);
a_fechaInicio.setText(data.fechainicio);
TextView a_fechafin= (TextView) convertView.findViewById(R.id.a_fechafin);
a_fechafin.setText(data.fechafin);
TextView a_tiemporiego1= (TextView) convertView.findViewById(R.id.a_tiemporiego1);
a_tiemporiego1.setText(data.tiemporiego1);
TextView a_diasSemana= (TextView) convertView.findViewById(R.id.a_diasSemana);
a_diasSemana.setText(data.diasSemana);
TextView a_horainicio1= (TextView) convertView.findViewById(R.id.a_horainicio1);
a_horainicio1.setText(data.horainicio1);
TextView a_horainicio2= (TextView) convertView.findViewById(R.id.a_horainicio2);
a_horainicio2.setText(data.horainicio2);
TextView a_tiemporiego2= (TextView) convertView.findViewById(R.id.a_tiemporiego2);
a_tiemporiego2.setText(data.tiemporiego2);
TextView a_humedad= (TextView) convertView.findViewById(R.id.a_humedad);
a_humedad.setText(data.humedad);
TextView a_sensibilidadLuz= (TextView) convertView.findViewById(R.id.a_sensibilidadLuz);
a_sensibilidadLuz.setText(data.sensibilidadLuz);
TextView a_nocheDia= (TextView) convertView.findViewById(R.id.a_nocheDia);
a_nocheDia.setText(data.nocheDia);
TextView a_nroSolenoide= (TextView) convertView.findViewById(R.id.a_nroSolenoide);
a_nroSolenoide.setText(data.nroSolenoide);


return convertView;
}

      

}

