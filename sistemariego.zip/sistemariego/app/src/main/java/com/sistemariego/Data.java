 
package com.sistemariego;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.content.Intent;
import android.os.Environment;
import android.app.Activity;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import com.sistemariego.DatosArduino;
import com.sistemariego.DatosArduinoH;
import com.sistemariego.DatosArduinoL;
import com.sistemariego.DatosArduinoR;
import com.sistemariego.DatosArduinoRString;
import com.sistemariego.DatosArduinoT;
import com.sistemariego.MainActivity;
import com.sistemariego.RComparator;
import com.sistemariego.Resumen;
import java.io.*;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;
import java.util.ArrayList;
import javax.xml.transform.URIResolver;
import android.os.Bundle;

public class Data {

public int request_code=0;
DatosArduinoT[] arrayDatosTiempo;
DatosArduinoH[] arrayDatosHumedad;
DatosArduinoL[] arrayDatosLuz;
DatosArduinoR[] arrayDatosResumen;
File pathData;

public String[] arrayDias = new String[]{"Todos los dias","Lunes", "Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"};

public Data(){

this.arrayDatosTiempo= new DatosArduinoT[6];

this.arrayDatosHumedad= new DatosArduinoH[6];

this.arrayDatosLuz = new DatosArduinoL[6];

this.arrayDatosResumen = new
DatosArduinoR[18];

};


  



public void programaSolenoideT(DatosArduinoT d,int nroSolenoide){
  this.arrayDatosTiempo[nroSolenoide]= d;
};

public void programaSolenoideL(DatosArduinoL d,int nroSolenoide){
  this.arrayDatosLuz[nroSolenoide]= d;
};

public void programaSolenoideH(DatosArduinoH d,int nroSolenoide){
  this.arrayDatosHumedad[nroSolenoide]= d;
};

public int solenoidesRegistradosT(){
   int compara=-1;
  for (int i=0; i < arrayDatosTiempo.length; i++){
    if (arrayDatosTiempo[i]!=null){
    
    compara= compara + arrayDatosTiempo[i].getFechaInicio();};
  };
  return compara;
};

public int solenoidesRegistradosH(){
   int compara=-1;
  for (int i=0; i < arrayDatosHumedad.length; i++){
    if (arrayDatosHumedad[i]!=null){
    compara= compara + arrayDatosHumedad[i].getFechaInicio();};
  };
  
  return compara;
};
public int getFechaInicioDataL(int nroSolenoide){
  int d=-1;
  if (arrayDatosLuz[nroSolenoide]!=null){ d=this.arrayDatosLuz[nroSolenoide].getFechaInicio();};
  return d;
};

public int solenoidesRegistradosL(){
   int compara=-1;
   for (int i=0; i < arrayDatosLuz.length; i++){
    if (arrayDatosLuz[i]!=null){
     compara= compara + arrayDatosLuz[i].getFechaInicio();};
  };
  return compara;
};

public int getFechaInicioDataT(int nroSolenoide){
int d;
  if (arrayDatosTiempo[nroSolenoide]!=null){
  d= this.arrayDatosTiempo[nroSolenoide].getFechaInicio();
}else{
d=-1;};
  return d;
};

public void activaSolenoideT(int activa){

for (int i=0; i < arrayDatosTiempo.length; i++){
    if (arrayDatosTiempo[i]!=null){
if(this.arrayDatosTiempo[i].getFechaInicio()>0){
this.arrayDatosTiempo[i].setActivado(activa);}
}};
};

public int getFechaInicioDataH(int nroSolenoide){
  int d=-1;
  if (arrayDatosHumedad[nroSolenoide]!=null){ d=this.arrayDatosHumedad[nroSolenoide].getFechaInicio();};
  return d;
};

public void activaSolenoideH(int activa){
  
  for (int i=0; i < arrayDatosHumedad.length; i++){
    if (arrayDatosHumedad[i]!=null){
if(this.arrayDatosHumedad[i].getFechaInicio()>0){
this.arrayDatosHumedad[i].setActivado(activa);}
}};
};

public void activaSolenoideL(int activa){
  
  for (int i=0; i < arrayDatosLuz.length; i++){
    if (arrayDatosLuz[i]!=null){
if(this.arrayDatosLuz[i].getFechaInicio()>0){
this.arrayDatosLuz[i].setActivado(activa);}
}};
};

public void setAndOrT(int activa){

for (int i=0; i < arrayDatosTiempo.length; i++){
    if (arrayDatosTiempo[i]!=null){
if(this.arrayDatosTiempo[i].getFechaInicio()>0){
this.arrayDatosTiempo[i].setAndOr(activa);}
}};
};

public void setAndOrH(int activa){
  
  for (int i=0; i < arrayDatosHumedad.length; i++){
    if (arrayDatosHumedad[i]!=null){
if(this.arrayDatosHumedad[i].getFechaInicio()>0){
this.arrayDatosHumedad[i].setAndOr(activa);}
}};
};

public void setAndOrL(int activa){
  
  for (int i=0; i < arrayDatosLuz.length; i++){
    if (arrayDatosLuz[i]!=null){
if(this.arrayDatosLuz[i].getFechaInicio()>0){
this.arrayDatosLuz[i].setAndOr(activa);}
}};
};
DatosArduinoRString data;
public ArrayList<DatosArduinoRString> FabricaResumen(){
  for (int i=0; i < arrayDatosResumen.length; i++){
  arrayDatosResumen[i]=null;};
  int contador=0;
  for (int i=0; i < arrayDatosTiempo.length; i++){
    if (arrayDatosTiempo[i]!=null){
if((this.arrayDatosTiempo[i].getFechaInicio()>0) & (this.arrayDatosTiempo[i].getActivado()>0)){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia )
arrayDatosResumen[contador]=new DatosArduinoR(
arrayDatosTiempo[i].getActivado(), arrayDatosTiempo[i].getAndOr(),
arrayDatosTiempo[i].getFechaInicio(),
arrayDatosTiempo[i].getFechaFin(),
arrayDatosTiempo[i].getTiempoRiego1(),
arrayDatosTiempo[i].getDiasSemana(),
arrayDatosTiempo[i].getHoraInicio1(),
arrayDatosTiempo[i].getHoraInicio2(),
arrayDatosTiempo[i].getTiempoRiego2(),
0,0,-1,(i+1));
  contador=contador + 1;
}}};
 for (int i=0; i < arrayDatosHumedad.length; i++){
    if (arrayDatosHumedad[i]!=null){
if((this.arrayDatosHumedad[i].getFechaInicio()>0) & (this.arrayDatosHumedad[i].getActivado()>0)){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia)
arrayDatosResumen[contador]=new DatosArduinoR(
arrayDatosHumedad[i].getActivado(), arrayDatosHumedad[i].getAndOr(),
arrayDatosHumedad[i].getFechaInicio(),
arrayDatosHumedad[i].getFechaFin(),
arrayDatosHumedad[i].getTiempoRiego1(),
arrayDatosHumedad[i].getDiasSemana(),
999999,
999999,
999999,
arrayDatosHumedad[i].getHumedad(),
0,-1,(i+1));
  contador=contador+1;
}}};
for (int i=0; i < arrayDatosLuz.length; i++){
    if (arrayDatosLuz[i]!=null){
if((this.arrayDatosLuz[i].getFechaInicio()>0) & (this.arrayDatosLuz[i].getActivado()>0)){
//DatosArduinoR(int activado, int andOr, int fechainicio,int fechafin,int tiemporiego1,int diasSemana,int horainicio1,int horainicio2,int tiemporiego2,int humedad, int sensibilidadLuz, int nocheDia)

arrayDatosResumen[contador]=new DatosArduinoR(
arrayDatosLuz[i].getActivado(), arrayDatosLuz[i].getAndOr(),
arrayDatosLuz[i].getFechaInicio(),
arrayDatosLuz[i].getFechaFin(),
arrayDatosLuz[i].getTiempoRiego1(),
arrayDatosLuz[i].getDiasSemana(),
999999,
999999,
999999,
0,
arrayDatosLuz[i].getSensibilidadLuz(),
arrayDatosLuz[i].getNocheDia(),(i+1));
  contador=contador+1;
}}};
ArrayList<DatosArduinoR> listaResumen =
new ArrayList<DatosArduinoR>();
listaResumen.clear();
int c=0;
for (int i=0; i < arrayDatosResumen.length; i++){
if(arrayDatosResumen[i]!=null){
 c=c+1; listaResumen.add(arrayDatosResumen[i]);
};};
if(c==0){
  listaResumen.add(new DatosArduinoR(-1,0,0,0,0,0,0,0,0,0,0,-1,0));
  };
Collections.sort(listaResumen,new RComparator());


ArrayList<DatosArduinoRString> LResumenString =
new ArrayList<DatosArduinoRString>();


for (int i=0; i < listaResumen.size();i++){ 

//(String activado, String andOr, String fechainicio,String fechafin,String tiemporiego1,String diasSemana,String horainicio1,String horainicio2,String tiemporiego2,String humedad, String sensibilidadLuz, String nocheDia, String nroSolenoide){
data = null;
data = new DatosArduinoRString(
activado(listaResumen.get(i).getActivado()),
andor(listaResumen.get(i).getAndOr()),
makeintdate(listaResumen.get(i).getFechaInicio()),
makeintdate(listaResumen.get(i).getFechaFin()),
maketimertext(listaResumen.get(i).getTiempoRiego1()),
 diasSeleccionados(listaResumen.get(i).getDiasSemana()),
makeinttime(listaResumen.get(i).getHoraInicio1()),
makeinttime(listaResumen.get(i).getHoraInicio2()),
maketimertext(listaResumen.get(i).getTiempoRiego2()),
Integer.toString(listaResumen.get(i).getHumedad()),
Integer.toString(listaResumen.get(i).getSensibilidadLuz()),
nochedia(listaResumen.get(i).getNocheDia()),
Integer.toString(listaResumen.get(i).getNroSolenoide()));

 LResumenString.add(data);
 };

return LResumenString;
};

public String makeintdate(int a){
int y = a/10000;
int m = (a-(y*10000))/100;
int d = (a-(y*10000+m*100));
StringBuilder b = new StringBuilder().
append(y).
append("/").
append(m).
append("/").
append(d);
return b.toString();

};

public String makeinttime(int a){

int h =a/100;
int m = (a-(h*100));
StringBuilder b = new StringBuilder().
append("(H:M)24hrs").
append(h).
append(":").
append(m);
return b.toString();
};
public String maketimertext(int t){

StringBuilder txt = new  StringBuilder().append(t).append(" Min.");
return txt.toString();};

public String diasSeleccionados(int diasSelected) {

if (Resumen.languageAdap==1){
arrayDias[0]="Every day";
arrayDias[1]="Monday";
arrayDias[2]="Tuesday";
arrayDias[3]="Wedneaday";
arrayDias[4]="Thursday";
arrayDias[5]="Friday";
arrayDias[6]="Saturday";
arrayDias[7]="Sunday";
};

String txtDiasSelected;

  if ((diasSelected/128)==1){
    txtDiasSelected= arrayDias[0];
  }
  else{
    StringBuilder builDias =
     new StringBuilder();
     for (int i = 0; i < 7; i++){
      int diasselector=diasSelected & (int)(Math.pow((double)2,(double)i));
      int bitOn = diasselector >> i;
       if (bitOn==1){ builDias.append(arrayDias[i+1]).append("  ");
       };
     };
     
  txtDiasSelected = builDias.toString(); 
   
     };
     return txtDiasSelected;
  };
public String nochedia(int d){
  if(d==3){ return "D & N";}
  else if(d==2){
    return "D";}
    else if(d==1){
      return "N";}
      else return "-";
}
public String activado(int d){
  if(d==1){
    return "ON";
  }else return "OFF";
}
public String andor(int d){
  if(d==2){
    return "AND";
  }else if(d==1){
    return "OR"; }
    else return "-";
}

public void saveData(Activity activity, Context context,int option){

String dirpath =Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)+"/"+"sistemariego";

try{
StorageManager sm = (StorageManager)context.getSystemService(Context.STORAGE_SERVICE);
StorageVolume volume = sm.getPrimaryStorageVolume();
String volPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
Intent intent = volume.createAccessIntent(volPath);
ContentResolver contentResolver = context.getContentResolver();
String uriString = "content://com.sistemariego/"+ Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
Uri pathUri = Uri.parse(uriString);


activity.startActivityForResult(intent, request_code);
if (request_code == Activity.RESULT_OK){
contentResolver.takePersistableUriPermission(pathUri,request_code);};


File file = new File(dirpath); 

    if (!file.mkdirs()) {
    File filemkdir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"sistemariego");
        filemkdir.mkdir();
    }
}
catch(Exception e){Resumen.errorMsg(e.toString());
  }
ObjectOutputStream serializatorDataR=null;
ObjectOutputStream serializatorDataT=null;
ObjectOutputStream serializatorDataL=null;
ObjectOutputStream serializatorDataH=null;
FileOutputStream arduinoDataR=null;
FileOutputStream arduinoDataT=null;
FileOutputStream arduinoDataH=null;
FileOutputStream arduinoDataL=null;
FileDescriptor fdR=null;
FileDescriptor fdT=null;
FileDescriptor fdH=null;
FileDescriptor fdL=null;
try {
switch (option){




  case 1:
  
  break;
  case 2:
  
  
  break;
  
  default:
  
  
  break;
}

File fileNameR = new File(dirpath, "arduino_data_resumen.txt");
File fileNameT = new File(dirpath, "arduino_data_tiempo.txt");
File fileNameH = new File(dirpath, "arduino_data_humedad.txt");
File fileNameL = new File(dirpath, "arduino_data_luz.txt");



 
 arduinoDataR = new FileOutputStream(fileNameR);
 fdR=arduinoDataR.getFD();
 serializatorDataR = new ObjectOutputStream(arduinoDataR);
  
serializatorDataR.writeObject(MainActivity.allData.arrayDatosResumen);

serializatorDataR.flush();
fdR.sync();
serializatorDataR.close();
  
  
arduinoDataT = new FileOutputStream(fileNameT);
 fdT=arduinoDataT.getFD();
 serializatorDataT = new ObjectOutputStream(arduinoDataT);
  
serializatorDataT.writeObject(MainActivity.allData.arrayDatosTiempo);

serializatorDataT.flush();
fdT.sync();
serializatorDataT.close();

arduinoDataH = new FileOutputStream(fileNameH);
 fdH=arduinoDataH.getFD();
 serializatorDataH = new ObjectOutputStream(arduinoDataH);
  
serializatorDataH.writeObject(MainActivity.allData.arrayDatosHumedad);

serializatorDataH.flush();
fdH.sync();
serializatorDataH.close();

arduinoDataL = new FileOutputStream(fileNameL);
 fdL=arduinoDataL.getFD();
 serializatorDataL = new ObjectOutputStream(arduinoDataL);
  
serializatorDataL.writeObject(MainActivity.allData.arrayDatosLuz);

serializatorDataL.flush();

fdL.sync();
serializatorDataL.close();

Resumen.toastsave();

 }
  catch(Exception e){Resumen.errorMsg(e.toString());
  }
  finally {

			if (serializatorDataR != null) {
				try {
					serializatorDataR.close();
				} catch (IOException e) {
					Resumen.errorMsg(e.toString());
				}
			};

			if (arduinoDataR != null) {
				try {
					arduinoDataR.close();
				} catch (IOException e) {
					Resumen.errorMsg(e.toString());
				}
			};

  	if (serializatorDataT != null) {
				try {
					serializatorDataR.close();
				} catch (IOException e) {
					Resumen.errorMsg(e.toString());
				}
			};

			if (arduinoDataT != null) {
				try {
					arduinoDataR.close();
				} catch (IOException e) {
					Resumen.errorMsg(e.toString());
				}
			};
  	if (serializatorDataH != null) {
				try {
					serializatorDataR.close();
				} catch (IOException e) {
					Resumen.errorMsg(e.toString());
				}
			};

			if (arduinoDataH != null) {
				try {
					arduinoDataR.close();
				} catch (Exception e) {
					Resumen.errorMsg(e.toString());
				}
			};
			if (serializatorDataL != null) {
				try {
					serializatorDataR.close();
				} catch (Exception e) {
					Resumen.errorMsg(e.toString());
				}
			};

			if (arduinoDataL != null) {
				try {
					arduinoDataR.close();
				} catch (Exception e) {
					Resumen.errorMsg(e.toString());
				}
			};

};
};
}
