package com.sistemariego;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.sistemariego.R;

public class Arduino extends Activity{

//private boolean english;
//private TextView titulo;
//private TextView arduino;

 @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.arduino);
        
Bundle bdlenglish = getIntent().getExtras();

final int language = (int) bdlenglish.getInt("traducir");

final TextView titulo = findViewById(R.id.titulo);
final TextView arduino = 
findViewById(R.id.arduino);
switch (language){
case 1:
titulo.setText("Automatic Watering System");
 arduino.setText("Arduino configuration");
 };

}
}
